#include <stdio.h>
int main(void)
{
    int m, n, arr[100], i, num, min;
    scanf("%d%d", &n, &m);
    for (i = 0; i < n; i++)
    {
        scanf("%d", &num);
        arr[i] = num;
    }
    for (i = 0; i <= n - m; i++)
    {
        if ((arr[i] + arr[i + 1] + arr[i + 2]) > (arr[i + 1] + arr[i + 2] + arr[i + 3]))
        {
            min = arr[i + 1] + arr[i + 2] + arr[i + 3];
        }
    }
    printf("%d", min);
    system("pause");
    return 0;
}