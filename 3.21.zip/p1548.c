#include <stdio.h>
int main(void)
{
    int N, M, zCnt = 0, sum = 0, i, j, temp;
    scanf("%d%d", &N, &M);
    if (N < M)
    {
        temp = N;
        N = M;
        M = temp;
    }
    for (i = 0; i < M; i++)
    {
        zCnt += ((M - i) * (N - i));
    }
    for (i = 0; i < M; i++)
    {
        for (j = 0; j < N; j++)
        {
            sum += ((N - j) * (M - i));
        }
    }
    printf("%d %d", zCnt, sum - zCnt);
    system("pause");
    return 0;
}