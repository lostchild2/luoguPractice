#include <stdio.h>
int arr[10];
int main(void)
{
    int beg, end, i, j, index, temp;
    scanf("%d%d", &beg, &end);
    for (i = beg; i <= end; i++)
    {
        temp = i;
        do
        {
            arr[i % 10]++;
        } while (i /= 10);
        i = temp;
    }
    for (i = 0; i < 10; i++)
    {
        printf("%d ", arr[i]);
    }
    system("pause");
    return 0;
}