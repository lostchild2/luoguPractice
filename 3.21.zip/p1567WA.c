#include <stdio.h>
int main(void)
{
    int N, arr[10000], i, j, num, cnt = 1, arr2[1000], cnt2 = -1, max;
    scanf("%d", &N);
    for (i = 0; i < N; i++)
    {
        scanf("%d", &num);
        arr[i] = num;
        if (arr[i - 1] < arr[i] && i > 0)
        {
            cnt++;
            if (i == (N - 1))
            {
                cnt2++;
                arr2[cnt2] = cnt;
                cnt = 1;
            }
        }
        else if (i > 0)
        {
            cnt2++;
            arr2[cnt2] = cnt;
            cnt = 1;
        }
    }
    for (i = 0; i < cnt2; i++)
    {
        max = arr2[0];
        if (arr2[i - 1] < arr2[i] && i > 0)
        {
            max = arr2[i];
        }
    }
    printf("%d", max);
    system("pause");
    return 0;
}