#include <stdio.h>
int main(void)
{
    int a, b, c;
    scanf("a:=%d;b:=%d;c:=%d", &a, &b, &c);
    printf("%d %d %d", a, b, c);
    system("pause");
    return 0;
}