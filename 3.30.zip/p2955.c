#include <stdio.h>
int main(void)
{
    int n, num, i, arr[100000];
    scanf("%d", &n);
    for (i = 0; i < n; i++)
    {
        scanf("%d", &num);
        if (num % 2 == 0)
        {
            arr[i] = 0;
        }
        else
        {
            arr[i] = 1;
        }
    }
    for (i = 0; i < n; i++)
    {
        if (arr[i] == 0)
        {
            printf("even\n");
        }
        else
        {
            printf("odd\n");
        }
    }
    system("pause");
    return 0;
}