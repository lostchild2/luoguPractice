#include <stdio.h>
int sum(int n, int k)
{
    if ((n + k) % 2 == 0 && n > k + 1)
    {
        return sum((n + k) / 2, k) + sum((n - k) / 2, k);
    }
    else
    {
        return 1;
    }
}
int main(void)
{
    int n, k;
    scanf("%d%d", &n, &k);
    int ret = sum(n, k);
    printf("%d", ret);
    system("pause");
    return 0;
}