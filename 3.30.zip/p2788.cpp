#include <iostream>
using namespace std;
int ans, t;
int main()
{
    while (cin >> t)
        ans += t; //读入并计算
    cout << ans;  //输出
    return 0;
}