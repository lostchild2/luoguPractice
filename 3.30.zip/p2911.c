#include <stdio.h>
int arr[81] = {0};
int main(void)
{
    int i = 0, s1, s2, s3;
    scanf("%d%d%d", &s1, &s2, &s3);
    int sum = s1 + s2 + s3;
    int a, b;
    for (i = 1; i <= s1; i++)
    {
        for (a = 1; a <= s2; a++)
        {
            for (b = 1; b <= s3; b++)
            {
                arr[i + a + b]++;
                // printf("%d ", arr4[i * a * b]);
            }
        }
    }
    int max = 0, temp = 0;
    for (i = 3; i <= sum; i++)
    {
        if (arr[i] > max)
        {
            max = arr[i];
            temp = i;
        }
    }
    printf("%d", temp);
    system("pause");
    return 0;
}