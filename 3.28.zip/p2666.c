#include <stdio.h>
#include <math.h>
int main(void)
{
    int arr[4], arr2[10001]; // arr是a,b,c,d四个数据,arr2储存平方数
    int N;
    int a, b, c, d, temp, cnt = 0;
    scanf("%d", &N);
    double i = sqrt(N);
    for (a = 0; a <= i; a++)
    {
        for (b = 0; b <= i; b++)
        {
            if (a * a + b * b > N)
            {
                break;
            }
            for (c = 0; c <= i; c++)
            {
                temp = N - a * a - b * b - c * c;
                d = sqrt(temp);
                // printf("temp=%d d=%d \n", temp, d);
                if (temp == d * d)
                {
                    cnt++;
                }
            }
        }
    }
    printf("%d", cnt);
    system("pause");
    return 0;
}