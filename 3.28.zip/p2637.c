#include <stdio.h>
int main(void)
{
    int n, m, arr[1001], num;
    scanf("%d%d", &n, &m); // n批草m个人
    int i = 0;
    for (i = 0; i < m; i++)
    {
        scanf("%d", &num);
        arr[i] = num;
    } //赋值,index是农民的价格
    int j = 0;
    int temp = 0;
    for (i = 0; i < m - 1; i++)
    {
        for (j = i + 1; j < m; j++)
        {
            if (arr[i] > arr[j])
            {
                temp = arr[i];
                arr[i] = arr[j];
                arr[j] = temp;
            }
        }
    } //从小到大排序
    int ams = 0, max = 0;
    for (i = 0; i < m; i++)
    {
        if (m - i <= n)
        { //草如果够用
            if (arr[i] * (m - i) > max)
            {
                max = arr[i] * (m - i);
                temp = i;
            }
        }
        else
        { //草如果不够用
            max = arr[m - n] * n;
        }
    }
    printf("%d %d", arr[temp], max);
    system("pause");
    return 0;
}