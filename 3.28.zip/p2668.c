#include <stdio.h>
int main(void)
{
    int k; // k天
    int i = 1, j, money = 0, sum = 0;
    scanf("%d", &k);
    while ((sum += i) <= k)
    {
        money += (i * i);
        i++;
    }
    sum -= i;
    money += ((k - sum) * i);
    printf("%d", money);
    system("pause");
    return 0;
}