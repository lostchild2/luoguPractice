#include <stdio.h>
int arr3[7] = {0};
int main(void)
{
    int n, arr[7], arr2[7], i, j, num, cnt = 0, a;
    // arr[7]是中奖号码,arr2[7]是小明买的号码,arr3[7]储存什么奖中了多少次
    scanf("%d", &n);
    for (i = 0; i < 7; i++)
    {
        scanf("%d", &num);
        arr[i] = num;
    } //储存中奖号码
    for (i = 0; i < n; i++)
    { //买了n张
        for (j = 0; j < 7; j++)
        {
            scanf("%d", &num);
            for (a = 0; a < 7; a++)
            {
                if (arr[a] == num)
                {
                    cnt++;
                }
            }
        }
        if (cnt != 0)
        {
            arr3[7 - cnt] += 1;
        }
        cnt = 0;
    }
    for (i = 0; i < 7; i++)
    {
        printf("%d ", arr3[i]);
    }
    system("pause");
    return 0;
}