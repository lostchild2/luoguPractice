#include <stdio.h>
int main(void)
{
    int n, arr[10], i, num, j, cnt = 0, a, mul = 1, sum = 0, arr2[10], arr3[10], arr4[11] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10}, b;
    // arr[10]用来储存原来的数据,arr2[10]储存相应位数后面有几个比他小的数据个数,arr3[10]是我原来的做法，被优化了，arr4[10]是输出数据可能要的数字，被输出的赋0
    scanf("%d", &n);
    for (i = 0; i < n; i++)
    {
        scanf("%d", &num);
        arr[i] = num;
    }
    for (i = 0; i < n - 1; i++)
    {
        for (j = i + 1; j < n; j++)
        {
            if (arr[i] > arr[j])
            {
                cnt++;
            }
        }
        for (a = n - i - 1; a > 0; a--)
        {
            mul *= a;
        }
        sum += (cnt * mul);
        mul = 1;
        cnt = 0;
    }
    sum -= 1; // sum指前面有几个数
    // printf("sum=%d ", sum);
    if (sum == -1)
    {
        printf("ERROR");
        system("pause");
        return 0;
    }
    for (i = 0; i < n - 1; i++)
    {
        for (a = n - i - 1; a > 0; a--)
        {
            mul *= a;
        }
        arr2[i] = sum / mul;
        // printf("arr2[%d]=%d ", i, arr2[i]);
        sum = sum % mul;
        mul = 1;
    }
    printf("\n");
    cnt = 0;
    int temp = 0;
    for (i = 0; i < n; i++)
    {
        for (j = 0; j < n; j++)
        {
            if (arr2[i] == cnt) //已经跨越了足够的数据
            {
                temp = j;
                if (arr4[j] == 0) //判断后面的数据是否为0
                {
                    while (arr4[j] == 0)
                    {
                        j++;
                    }
                }
                printf("%d ", arr4[j]);
                arr3[i] = arr4[j];
                arr4[j] = 0;
                j = temp;
                break;
            }
            if (arr4[j] != 0)
            {
                cnt++;
            }
        }
        cnt = 0;
    }
    // printf("\n");
    // for (i = 0; i < n - 1; i++)
    // {
    //     if (i == 0)
    //     {
    //         arr3[i] = arr2[i] + 1;
    //     }
    //     else if (i > 0 && i < n - 1)
    //     {
    //         for (j = 0; j < i; j++)
    //         {
    //             if (arr2[j] <= arr2[i])
    //             {
    //                 cnt++;
    //             }
    //         }
    //         arr3[i] = arr2[i] + cnt + 1;
    //     }
    //     cnt = 0;
    // }
    // for (a = 1; a <= n; a++)
    // {
    //     for (b = 0; b < n - 1; b++)
    //     {
    //         if (arr3[b] == a)
    //         {
    //             break;
    //         }
    //     }
    //     if (b >= n - 1)
    //     {
    //         printf("%d", a);
    //         break;
    //     }
    // }
    // for (i = 0; i < n; i++)
    // {
    //     printf("%d ", arr3[i]);
    // }
    system("pause");
    return 0;
}