#include <stdio.h>
int main(void)
{
    int arr[10001] = {0}, cnt = 1, tempCnt = 1;
    char ch;
    while ((ch = getchar()) != '\n')
    {
        arr[cnt] = (ch - '0') * 2;
        tempCnt = cnt; //重新定位
        while (arr[tempCnt] >= 10)
        { //判断是否进位
            arr[tempCnt] -= 10;
            arr[tempCnt - 1]++;
            tempCnt--; //前进一位
        }
        cnt++;
    }
    cnt--;
    tempCnt = cnt;
    if (arr[cnt] == 0)
    {
        while (arr[tempCnt] == 0)
        {
            arr[tempCnt] = 9;
            arr[tempCnt - 1]--;
            tempCnt--;
        }
    }
    else
    {
        arr[cnt] -= 1;
    }
    for (int i = 0; i <= cnt; i++)
    {
        if (i == 0 && arr[i] == 0)
        {
        }
        else
        {
            printf("%d", arr[i]);
        }
    }
    system("pause");
    return 0;
}