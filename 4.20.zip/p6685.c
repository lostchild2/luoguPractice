#include <stdio.h>
#include <math.h>
int main(void)
{
    long long n, m, mul = 1;
    scanf("%lld%lld", &n, &m);
    printf("%d", (int)(sqrt(n)));
    // int cnt = 0;
    // for (int i = 1;; i++)
    // {
    //     mul = i;
    //     for (int j = 2; j <= m; j++)
    //     {
    //         mul = (mul * mul);
    //     }
    //     if (mul <= n)
    //     {
    //         cnt++;
    //     }
    //     else
    //     {
    //         break;
    //     }
    // }
    // printf("%d", cnt);
    system("pause");
    return 0;
}