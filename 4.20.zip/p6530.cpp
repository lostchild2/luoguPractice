#include <iostream>
using namespace std;
int n, a[100003], ans = 0;
int cmp(int a, int b)
{
	return a > b;
	//将sort变成降序排列
}
int main()
{
	cin >> n;
	for (int i = 1; i <= n; i++)
		cin >> a[i];
	sort(a + 1, a + n + 1, cmp);
	for (int i = 3; i <= n; i = i + 3)
		a[i] = 0;
	for (int i = 1; i <= n; i++)
		ans = ans + a[i];
	cout << ans;
	return 0;
}