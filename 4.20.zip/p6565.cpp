#include <iostream>
using namespace std;
struct stu
{
	string name;
	string str;
};
int main()
{
	int n, max = 0, cnt = 0, len;
	string ans;
	int arr[105];
	struct stu stu[105];
	cin >> n;
	for (int i = 1; i <= n; i++)
	{
		cin >> stu[i].name >> stu[i].str;
		len = stu[i].str.length() - 2;
		for (int j = 0; j < len; j++)
		{
			if (stu[i].str.substr(j, 3) == "sos")
			{
				cnt++;
			}
		}
		if (cnt > max)
		{
			max = cnt;
		}
		arr[i] = cnt;
		cnt = 0;
	}
	for (int i = 1; i <= n; i++)
	{
		if (arr[i] == max)
		{
			cout << stu[i].name << " ";
		}
	}

	cout << endl
		 << max;
	// cout << ans << endl << max;
	return 0;
}