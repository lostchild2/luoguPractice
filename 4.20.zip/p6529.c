#include <stdio.h>
#include <string.h>
int main(void)
{
    char str[1005];
    int index = 0, flag = 1;
    scanf("%s", str);
    int p[1005] = {0}, k[1005] = {0}, h[1005] = {0}, t[1005] = {0}, len = strlen(str);
    for (int i = 0; i < len; i += 3)
    {
        if (str[i] == 'P')
        {
            index += (str[i + 1] - '0') * 10;
            index += (str[i + 2] - '0');
            if (p[index] == 0)
            {
                p[index] = index;
            }
            else
            {
                printf("GRESKA");
                flag = 0;
                break;
            }
            index = 0;
        }
        else if (str[i] == 'K')
        {
            index += (str[i + 1] - '0') * 10;
            index += (str[i + 2] - '0');
            if (k[index] == 0)
            {
                k[index] = index;
            }
            else
            {
                printf("GRESKA");
                flag = 0;
                break;
            }
            index = 0;
        }
        else if (str[i] == 'H')
        {
            index += (str[i + 1] - '0') * 10;
            index += (str[i + 2] - '0');
            if (h[index] == 0)
            {
                h[index] = index;
            }
            else
            {
                printf("GRESKA");
                flag = 0;
                break;
            }
            index = 0;
        }
        else if (str[i] == 'T')
        {
            index += (str[i + 1] - '0') * 10;
            index += (str[i + 2] - '0');
            if (t[index] == 0)
            {
                t[index] = index;
            }
            else
            {
                printf("GRESKA");
                flag = 0;
                break;
            }
            index = 0;
        }
    }
    int cnt = 0;
    if (flag)
    {
        for (int i = 1; i <= 13; i++)
        {
            if (p[i] != 0)
            {
                cnt++;
            }
        }
        printf("%d ", 13 - cnt);
        cnt = 0;
        for (int i = 1; i <= 13; i++)
        {
            if (k[i] != 0)
            {
                cnt++;
            }
        }
        printf("%d ", 13 - cnt);
        cnt = 0;
        for (int i = 1; i <= 13; i++)
        {
            if (h[i] != 0)
            {
                cnt++;
            }
        }
        printf("%d ", 13 - cnt);
        cnt = 0;
        for (int i = 1; i <= 13; i++)
        {
            if (t[i] != 0)
            {
                cnt++;
            }
        }
        printf("%d ", 13 - cnt);
        cnt = 0;
    }
    system("pause");
    return 0;
}