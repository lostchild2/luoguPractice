#include <stdio.h>
int main(void)
{
    long long a, b, c;
    scanf("%lld%lld%lld", &a, &b, &c);
    if (a * a > b * c)
    {
        printf("Alice");
    }
    else
    {
        printf("Bob");
    }
    system("pause");
    return 0;
}