#include <stdio.h>
int max(int x, int y)
{
    if (x > y)
    {
        return x;
    }
    else
    {
        return y;
    }
}
int min(int x, int y)
{
    if (x > y)
    {
        return y;
    }
    else
    {
        return x;
    }
}
int main(void)
{
    int l, n, a;
    scanf("%d", &l);
    scanf("%d", &n);
    int mina = n;
    int maxa = 0;
    for (int i = 0; i < n; i++)
    {
        scanf("%d", &a);
        mina = min(mina, min(a + 1, l - a + 1));
        maxa = max(maxa, max(a + 1, l - a + 1));
    }
    printf("%d %d", mina, maxa);
    system("pause");
    return 0;
}