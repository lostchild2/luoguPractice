#include <iostream>
int main()
{
    using namespace std;
    int n, m, k, a, t = 0, sum = 0; // n级台阶,一次m阶,k个特殊平台
    cin >> n >> m >> k;
    int arr[11];
    for (int i = 0; i < k; i++)
    {
        cin >> a;
        arr[i] = a;
        // cout << arr[i];
    }
    for (int i = 0; i < k - 1; i++)
    {
        for (int j = 0; j < k - 1 - i; j++)
        {
            int temp = 0;
            if (arr[j] > arr[j + 1])
            {
                temp = arr[j];
                arr[j] = arr[j + 1];
                arr[j + 1] = temp;
            }
        }
    }
    int i = 0;
    while (sum < n)
    {
        if (arr[i] == sum)
        {
            i++;
            m++;
        }
        sum += m;
        t++;
    }
    cout << t;
    return 0;
}