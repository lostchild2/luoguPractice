#include<stdio.h>
#include<string.h>
int main(void)
{
    char arr[9];
    scanf("%s",arr);
    int len=strlen(arr);
    int ans=0;
    for(int i=0;i<len;i++){
        if(arr[i]=='1'){
            ans++;
        }
    }
    printf("%d",ans);
    system("pause");
    return 0;
}