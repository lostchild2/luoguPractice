#include <stdio.h>
int main(void)
{
    int month, day;
    scanf("%d-%d", &month, &day);
    int ans = 0;
    int arr[12] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
    if (month > 12)
    {
        ans++;
        if (month % 10 > 2 && month / 10 % 10 > 1)
        {
            ans++;
        }
        month = 1;
    }
    if (day > arr[month - 1])
    {
        ans++;
    }
    printf("%d", ans);
    system("pause");
    return 0;
}