#include <iostream>
using namespace std;
int main()
{
	string ch, a, b, c, d;
	int x, y, z;
	int n, cnt;
	cin >> n;
	cin >> ch;
	for (int i = 1; i <= n; i++)
	{
		cin >> cnt;
		if (cnt == 1)
		{
			cin >> a;
			ch += a;
			cout << ch << endl;
		}
		else if (cnt == 2)
		{
			cin >> x >> y;
			ch = ch.substr(x, y);
			cout << ch << endl;
		}
		else if (cnt == 3)
		{
			cin >> z >> c;
			ch.insert(z, c);
			cout << ch << endl;
		}
		else if (cnt == 4) //操作4
		{
			cin >> d;
			if (ch.find(d) < ch.size())
				cout << ch.find(d) << endl;
			else
				cout << -1 << endl;
		}
	}
	return 0;
}