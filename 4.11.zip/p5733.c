#include <stdio.h>
#include <string.h>
int main(void)
{
    char ch[105];
    scanf("%s", ch);
    int len = strlen(ch);
    for (int i = 0; i < len; i++)
    {
        if (ch[i] >= 'a' && ch[i] <= 'z')
        {
            ch[i] = ch[i] - 'a' + 'A';
        }
    }
    printf("%s", ch);
    system("pause");
    return 0;
}