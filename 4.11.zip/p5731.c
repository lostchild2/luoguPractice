#include <stdio.h>
int main(void)
{
    int n, k = 1, x = 1, y = 0;
    int arr[11][11] = {0};
    scanf("%d", &n);
    while (k <= n * n)
    {
        while (y < n && arr[x][y + 1] == 0)
        {
            y++;
            arr[x][y] = k;
            k++;
        }
        while (x < n && arr[x + 1][y] == 0)
        {
            x++;
            arr[x][y] = k;
            k++;
        }
        while (y > 1 && arr[x][y - 1] == 0)
        {
            y--;
            arr[x][y] = k;
            k++;
        }
        while (x > 1 && arr[x - 1][y] == 0)
        {
            x--;
            arr[x][y] = k;
            k++;
        }
    }
    for (int i = 1; i <= n; i++)
    {
        for (int j = 1; j <= n; j++)
        {
            printf("%3d", arr[i][j]);
        }
        printf("\n");
    }
    system("pause");
    return 0;
}