#include <stdio.h>
#include <string.h>
int ch[102] = {0};
int ans = 0;
void judge(int i, int j)
{
    if (ch[i] == ch[j])
    {
        ans++;
        // printf("%c ", ch[i]);
        judge(i + 1, j + 1);
    }
}
int main(void)
{
    int n, max = 0;
    scanf("%d", &n);
    for (int i = 1; i <= n; i++)
    {
        scanf("%c", &ch[i]);
    }
    for (int i = 1; i <= n; i++)
    {
        for (int j = i + 1; j <= n; j++)
        {
            ans = 0;
            judge(i, j);
            if (ans > max)
            {
                max = ans;
            }
        }
    }
    printf("%d", max + 1);
    system("pause");
    return 0;
}