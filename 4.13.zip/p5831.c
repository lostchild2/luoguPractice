#include <stdio.h>
struct cow
{
    int num[25];
};
int main(void)
{
    struct cow cow[25];
    int k, n; // k场比赛，n头奶牛
    scanf("%d%d", &k, &n);
    for (int i = 0; i < k; i++)
    {
        for (int j = 0; j < n; j++)
        {
            scanf("%d", &cow[j].num[i]);
        }
    }
    int ans = 0;
    int dec = 0, inc = 0;
    for (int i = 0; i < n - 1; i++)
    {
        for (int j = i + 1; i < n; i++)
        {
            for (int a = 0; a < k; a++)
            {
                if (cow[i].num[a] < cow[j].num[a])
                {
                    dec++;
                }
                else
                {
                    inc++;
                }
            }
            if (dec == k || inc == k)
            {
                ans++;
            }
        }
    }
    printf("%d", ans);
    system("pause");
    return 0;
}