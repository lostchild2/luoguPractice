#include <stdio.h>
int main(void)
{
    int n, m, p, cnt, arr[100005] = {0}, num, ans[100005] = {0};
    scanf("%d%d%d", &n, &m, &p);
    for (int i = 0; i < n; i++)
    {
        scanf("%d", &cnt);
        for (int j = 0; j < cnt; j++)
        {
            scanf("%d", &num);
            arr[num]++;
        }
    }
    cnt = 0;
    for (int i = 1; i <= m; i++)
    {
        if (arr[i] == 2)
        {
            cnt++;
            ans[cnt] = i;
        }
    }
    printf("%d\n", cnt);
    for (int i = 1; i <= cnt; i++)
    {
        printf("%d\n", ans[i]);
    }
    system("pause");
    return 0;
}