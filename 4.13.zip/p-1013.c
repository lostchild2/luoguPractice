#include <stdio.h>
int main(void)
{
    int n, arr[101], pj = 0, ans = 0;
    scanf("%d", &n);
    for (int i = 0; i < n; i++)
    {
        scanf("%d", &arr[i]);
        pj += arr[i];
    }
    pj /= n;
    for (int i = 0; i < n; i++)
    {
        arr[i] -= pj;
        if (arr[i] != 0)
        {
            arr[i + 1] += arr[i];
            ans++;
        }
    }
    printf("%d", ans);
    system("pause");
    return 0;
}