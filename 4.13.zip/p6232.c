#include <stdio.h>
#include <string.h>
int main(void)
{
    char str[100];
    int a[9] = {0};
    scanf("%s", str);
    int len = strlen(str);
    for (int i = 0; i < len; i++)
    {
        if (str[i] == '1' || str[i] == 'Q' || str[i] == 'A' || str[i] == 'Z')
            a[1]++;
        if (str[i] == '2' || str[i] == 'W' || str[i] == 'S' || str[i] == 'X')
            a[2]++;
        if (str[i] == '3' || str[i] == 'E' || str[i] == 'D' || str[i] == 'C')
            a[3]++;
        if (str[i] == '4' || str[i] == 'R' || str[i] == 'F' || str[i] == 'V' || str[i] == '5' || str[i] == 'T' || str[i] == 'G' || str[i] == 'B')
            a[4]++;
        if (str[i] == '6' || str[i] == 'Y' || str[i] == 'H' || str[i] == 'N' || str[i] == '7' || str[i] == 'U' || str[i] == 'J' || str[i] == 'M')
            a[5]++;
        if (str[i] == '8' || str[i] == 'I' || str[i] == 'K' || str[i] == ',')
            a[6]++;
        if (str[i] == '9' || str[i] == 'O' || str[i] == 'L' || str[i] == '.')
            a[7]++;
        if (str[i] == '0' || str[i] == 'P' || str[i] == ';' || str[i] == '/' || str[i] == '-' || str[i] == '[' || str[i] == ']' || str[i] == '=' || str[i] == '\'')
            a[8]++;
    }
    for (int i = 1; i <= 8; i++)
    {
        printf("%d\n", a[i]);
    }
    system("pause");
    return 0;
}