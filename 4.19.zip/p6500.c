#include <stdio.h>
int main(void)
{
    int a, b, s1 = 0, s2 = 0, s = 1;
    scanf("%d%d", &a, &b);
    int tempa = a, tempb = b;
    do
    {
        if (tempa % 10 == 5)
        {
            s1 += s;
        }
        if (tempa % 10 == 6)
        {
            s2 += s;
        }
        s *= 10;
    } while (tempa /= 10);
    s = 1;
    do
    {
        if (tempb % 10 == 5)
        {
            s1 += s;
        }
        if (tempb % 10 == 6)
        {
            s2 += s;
        }
        s *= 10;
    } while (tempb /= 10);
    printf("%d %d", a + b - s2, a + b + s1);
    system("pause");
    return 0;
}
