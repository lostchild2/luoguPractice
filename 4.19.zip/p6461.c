#include <stdio.h>
#include <string.h>
int main(void)
{
    int arr[3] = {1, 0, 0};
    char ch;
    int temp = 0;
    while ((ch = getchar()) != '\n')
    {
        if (ch == 'A')
        {
            temp = arr[0];
            arr[0] = arr[1];
            arr[1] = temp;
        }
        if (ch == 'B')
        {
            temp = arr[1];
            arr[1] = arr[2];
            arr[2] = temp;
        }
        if (ch == 'C')
        {
            temp = arr[0];
            arr[0] = arr[2];
            arr[2] = temp;
        }
    }
    for (int i = 0; i < 3; i++)
    {
        if (arr[i] == 1)
        {
            printf("%d", i + 1);
            break;
        }
    }
    system("pause");
    return 0;
}