#include <stdio.h>
int main(void)
{
    int n, ans = 0, arr[1005], max = 0;
    scanf("%d", &n);
    for (int i = 1; i <= n; i++)
    {
        scanf("%d", &arr[i]);
        if (i > 1)
        {
            if (arr[i] - arr[i - 1] > 0)
            {
                ans += (arr[i] - arr[i - 1]);
            }
            else
            {
                ans = 0;
            }
        }
        if (ans > max)
        {
            max = ans;
        }
    }
    printf("%d", max);
    system("pause");
    return 0;
}