#include <stdio.h>
int main(void)
{
    int m, n, k, male, female;
    scanf("%d%d%d", &m, &n, &k);
    int sum = m + n - k;
    male = sum / 3;
    female = male * 2;
    if (male > n)
    {
        male = n;
    }
    if (female > m)
    {
        female = m;
    }
    if (male * 2 >= female)
    {
        }
    else
    {
        printf("%d", male);
    }
    system("pause");
    return 0;
}