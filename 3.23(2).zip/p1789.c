#include <stdio.h>
int main(void)
{
    int arr[100][100], n, i, j, a, b, cnt = 0;
    scanf("%d", &n);
    for (i = 0; i < n; i++)
    {
        for (j = 0; j < n; j++)
        {
            arr[i][j] = 0;
        }
    }
    do
    {
        scanf("%d%d", &a, &b);
        a--;
        b--;
        arr[a][b] = 1;
        arr[a + 1][b] = 1;
        arr[a + 2][b] = 1;
        arr[a][b + 1] = 1;
        arr[a][b + 2] = 1;
        arr[a + 1][b + 1] = 1;
        if (b - 1 > 0)
        {
            arr[a][b - 1] = 1;
            arr[a + 1][b - 1] = 1;
            if (a - 1 >= 0)
            {
                arr[a - 1][b - 1] = 1;
            }
            if (b - 2 >= 0)
            {
                arr[a][b - 2] = 1;
            }
        }
        if (a - 1 > 0)
        {
            arr[a - 1][b] = 1;
            arr[a - 1][b + 1] = 1;
            if (a - 2 >= 0)
            {
                arr[a - 2][b] = 1;
            }
        }
    } while ((a < 0) || (b < 0));
    for (i = 0; i < n; i++)
    {
        for (j = 0; j < n; j++)
        {
            if (arr[i][j] == 0)
            {
                cnt++;
            }
        }
    }
    printf("%d", cnt);
    system("pause");
    return 0;
}