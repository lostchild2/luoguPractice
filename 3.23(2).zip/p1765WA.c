#include <stdio.h>
int main(void)
{
    int arr[26] = {1, 2, 3, 1, 2, 3, 1, 2, 3, 1, 2, 3, 1, 2, 3, 1, 2, 3, 4, 1, 2, 3, 1, 2, 3, 4};
    char ch;
    int cnt = 0;
    while ((ch = getchar()) != EOF)
    {
        if (ch == ' ' || ch == '\n')
        {
            cnt++;
            continue;
        }
        if (ch == '\r')
        {
            cnt++;
            continue;
        }
        cnt += arr[ch - 'a'];
    }
    printf("%d", cnt);
    system("pause");
    return 0;
}