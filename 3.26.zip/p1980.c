#include <stdio.h>
int main(void)
{
    int arr[10], n, x, i, cnt = 0, temp;
    scanf("%d%d", &n, &x);
    for (i = 1; i <= n; i++)
    {
        temp = i;
        do
        {
            if (i % 10 == x)
            {
                cnt++;
            }
        } while (i /= 10);
        i = temp;
    }
    printf("%d", cnt);
    system("pause");
    return 0;
}