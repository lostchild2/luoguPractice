#include <stdio.h>
#include <string.h>
int main(void)
{
    int m, len, i, j, flag = 0;
    char ch[10100];
    scanf("%d", &m);
    scanf("%s", ch);
    len = strlen(ch);
    for (i = 0; i <= len - 1; i++)
    {
        if (flag == 0)
        {
            if (ch[i] != '0')
            {
                printf("%c*%d^%d", ch[i], m, len - 1 - i);
                flag = 1;
            }
        }
        else
        {
            if (ch[i] != '0')
            {
                printf("+%c*%d^%d", ch[i], m, len - 1 - i);
            }
        }
    }
    system("pause");
    return 0;
}