#include <stdio.h>
int main(void)
{
    int n, price, num, i, ans = 0, flag = 0;
    scanf("%d", &n);
    for (i = 0; i < 3; i++)
    {
        scanf("%d%d", &num, &price);
        if (n % num)
        {
            price = (n / num) * price + price;
        }
        else
        {
            price = (n / num) * price;
        }
        if (price < ans)
        {
            ans = price;
        }
        else if (flag == 0)
        {
            ans = price;
            flag = 1;
        }
    }
    printf("%d", ans);
    system("pause");
    return 0;
}