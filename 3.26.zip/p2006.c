#include <stdio.h>
int main(void)
{
    int k, m, n, i, a, b, cnt = -1, flag = 0;
    long long arr[3000000];
    scanf("%d%d%d", &k, &n, &m);
    for (i = 1; i <= n; i++)
    {
        scanf("%d%d", &a, &b);
        if ((k / a * b) >= m || (a == 0 && b != 0))
        {
            cnt++;
            arr[cnt] = i;
            flag = 1;
        }
    }
    for (i = 0; i <= cnt; i++)
    {
        printf("%d ", arr[i]);
    }
    if (flag == 0)
    {
        printf("-1");
    }
    system("pause");
    return 0;
}