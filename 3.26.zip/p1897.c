#include <stdio.h>
int main(void)
{
    int n, num, i, arr[100000], max = 0, time, j, cnt = 0, temp, arr2[100000];
    scanf("%d", &n);
    for (i = 0; i < n; i++)
    {
        scanf("%d", &num);
        arr[i] = num;
        if (num > max)
        {
            max = num;
        }
    }
    time = max * 10;
    for (i = 1; i <= n; i++)
    {
        for (j = 0; j < n; j++)
        {
            if (arr[j] == i)
            {
                cnt++;
            }
        }
        arr2[i - 1] = cnt;
        cnt = 0;
    }
    for (i = 0; i < n; i++)
    {
        if (arr2[i] != 0)
        {
            time += (arr2[i] + 5);
        }
    }
    printf("%d", time);
    system("pause");
    return 0;
}