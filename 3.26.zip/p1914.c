#include <stdio.h>
int main(void)
{
    int n, i = -1;
    char ch;
    char arr[52];
    scanf("%d%*c", &n);
    while ((ch = getchar()) != '\n')
    {
        if (ch + n <= 'z')
        {
            i++;
            arr[i] = ch + n;
        }
        else
        {
            i++;
            arr[i] = ch - 26;
        }
    }
    printf("%s", arr);
    system("pause");
    return 0;
}