#include <stdio.h>
int main(void)
{
    int i, p, a, N, num = 1, cnt = 0, j;
    scanf("%d", &N);
    for (i = 1; i <= N; i++)
    {
        num *= i;
    }
    for (i = 2;; i++)
    {
        for (j = 2; j < i; j++)
        {
            if (i % j == 0)
            {
                i++;
                j = 2;
            }
        }
        while (num % i == 0)
        {
            cnt++;
            num /= i;
        }
        printf("%d %d\n", i, cnt);
        cnt = 0;
        if (num < i)
        {
            break;
        }
    }
    system("pause");
    return 0;
}