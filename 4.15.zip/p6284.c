#include<stdio.h>
int main(void)
{
    int x,n,arr[105],sum=0,num;
    scanf("%d",&x);
    scanf("%d",&n);
    for(int i=0;i<n;i++){
        scanf("%d",&num);
        sum+=num;
    }
    printf("%d",x*(n+1)-sum);
    system("pause");
    return 0;
}