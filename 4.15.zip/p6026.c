#include <stdio.h>
int main(void)
{
    long long n, ans = 0;
    scanf("%lld", &n);
    while (n != 1)
    {
        if (n % 2)
        {
            n = (n * 3 + 1);
            ans++;
        }
        else
        {
            n /= 2;
            ans++;
        }
    }
    printf("%lld", ans);
    system("pause");
    return 0;
}