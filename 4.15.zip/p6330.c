#include <stdio.h>
int main(void)
{
    int chang[3], kuan[3], ansc, ansk;
    for (int i = 0; i < 3; i++)
    {
        scanf("%d%d", &chang[i], &kuan[i]);
    }
    // for (int i = 0; i <2; i++)
    // {
    //     for(int a=i+1;a<3;a++){
    //         if(chang[i]<chang[a]){
    //             int temp=chang[i];
    //             chang[i]=chang[a];
    //             chang[a]=temp;
    //         }
    //     }
    // }
    // for (int i = 0; i <2; i++)
    // {
    //     for(int a=i+1;a<3;a++){
    //         if(kuan[i]<kuan[a]){
    //             int temp=kuan[i];
    //             kuan[i]=kuan[a];
    //             kuan[a]=temp;
    //         }
    //     }
    // }
    int j = 0;
    for (int i = 0; i < 3; i++)
    {
        for (j = 0; j < 3; j++)
        {
            if (chang[i] == chang[j] && i != j)
            {
                break;
            }
        }
        if (j >= 3)
        {
            ansc = i;
            break;
        }
    }
    for (int i = 0; i < 3; i++)
    {
        for (j = 0; j < 3; j++)
        {
            if (kuan[i] == kuan[j] && i != j)
            {
                break;
            }
        }
        if (j >= 3)
        {
            ansk = i;
            break;
        }
    }
    printf("%d %d", chang[ansc], kuan[ansk]);
    system("pause");
    return 0;
}