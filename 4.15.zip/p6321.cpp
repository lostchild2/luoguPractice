#include <iostream>
using namespace std;
char a[55][55];
int main()
{
	int r, c, zr, zc;		   //老老实实按题目定义
	cin >> r >> c >> zr >> zc; // r:原行数 c:原列数 zr：放大行数 zc放大列数
	for (int i = 1; i <= r; ++i)
	{
		for (int j = 1; j <= c; ++j)
		{
			cin >> a[i][j];
		}
	} //常规二维数组输入
	for (int i = 1; i <= r; i++)
	{ //四重循环
		//这里控制原行数
		for (int m = 1; m <= zr; m++)
		{
			//枚举放大后的行数
			for (int j = 1; j <= c; j++)
			{
				//这里控制原列数
				for (int l = 1; l <= zc; l++) //枚举放大后的列数
					putchar(a[i][j]);		  //输出 （快捷）
			}
			printf("\n"); //换行位置很重要 （在这一行所有列的字符输完 后再换行）
		}
	}
	return 0;
}