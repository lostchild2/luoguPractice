#include <stdio.h>
#include <math.h>
long long gys(int x, int y)
{
    if (x > y)
    {
        int temp = x;
        x = y;
        y = temp;
    }
    while (y % x != 0)
    {
        int temp = y % x;
        y = x;
        x = temp;
    }
    return x;
}
long long gbs(int x, int y)
{
    return x * y / gys(x, y);
}
int main(void)
{
    long long x, y, cnt = 0;
    scanf("%d%d", &x, &y);
    long long i, j;
    y = sqrt(double *(y));
    // printf("%d %d", gys(x, y), gbs(x, y));
    for (i = x; i <= y; i += x)
    {
        for (j = x; j <= y; j += x)
        {
            if (gys(i, j) == x && gbs(i, j) == y)
            {
                cnt++;
                // printf("%d %d ", i, j);
            }
        }
    }
    printf("%lld", cnt * 2);
    system("pause");
    return 0;
}