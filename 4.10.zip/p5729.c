#include <stdio.h>
int main(void)
{
    int arr[22][22][22] = {0};
    int q;
    int x, y, z;
    scanf("%d%d%d", &x, &y, &z);
    scanf("%d", &q);
    for (int i = 0; i < q; i++)
    {
        int x1, y1, z1, x2, y2, z2;
        scanf("%d%d%d%d%d%d", &x1, &y1, &z1, &x2, &y2, &z2);
        for (int a = x1; a <= x2; a++)
        {
            for (int b = y1; b <= y2; b++)
            {
                for (int c = z1; c <= z2; c++)
                {
                    arr[a][b][c] = 1;
                }
            }
        }
    }
    int ans = 0;
    for (int a = 1; a <= x; a++)
    {
        for (int b = 1; b <= y; b++)
        {
            for (int c = 1; c <= z; c++)
            {
                if (arr[a][b][c] == 0)
                {
                    ans++;
                }
            }
        }
    }
    printf("%d", ans);
    system("pause");
    return 0;
}