#include <stdio.h>
int main(void)
{
    int n, r, cnt = -1;
    char ch[22] = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k'};
    scanf("%d%d", &n, &r);
    int arr[101] = {r};
    do
    {
        cnt++;
        arr[cnt] = ch[n % r];
    } while ((n /= r) != '0');
    printf("%d=", n);
    for (int i = cnt; i >= 0; i--)
    {
        printf("%d", arr[i]);
    }
    printf("(base)%d", r);
    system("pause");
    return 0;
}