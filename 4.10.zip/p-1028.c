#include <stdio.h>
int main(void)
{
    int arr[1001];
    arr[0] = arr[1] = 1;
    int n;
    scanf("%d", &n);
    for (int i = 2; i <= n; i++)
    {
        if (i % 2 == 0)
        {
            arr[i] = arr[i - 1] + arr[i / 2];
        }
        else
        {
            arr[i] = arr[i - 1];
        }
    }
    printf("%d", arr[n]);
    system("pause");
    return 0;
}