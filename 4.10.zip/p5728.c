#include <stdio.h>
#include <math.h>
struct stu
{
    int Chi;
    int math;
    int Eng;
} stu;
int main(void)
{
    struct stu stu[1001];
    int n;
    int Chi, math, Eng;
    scanf("%d", &n);
    for (int i = 0; i < n; i++)
    {
        scanf("%d%d%d", &Chi, &math, &Eng);
        stu[i].Chi = Chi;
        stu[i].math = math;
        stu[i].Eng = Eng;
    }
    int ans = 0;
    for (int i = 0; i < n - 1; i++)
    {
        for (int j = i + 1; j < n; j++)
        {
            if (abs(stu[i].Chi - stu[j].Chi) <= 5 && abs(stu[i].Eng - stu[j].Eng) <= 5 && abs(stu[i].math - stu[j].math) <= 5 && abs(stu[i].Chi + stu[i].Eng + stu[i].math - stu[j].Chi - stu[j].math - stu[j].Eng) <= 10)
            {
                ans++;
            }
        }
    }
    printf("%d", ans);
    system("pause");
    return 0;
}
