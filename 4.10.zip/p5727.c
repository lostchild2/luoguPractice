#include <stdio.h>
int main(void)
{
    int n, cnt = 0, arr[10001];
    scanf("%d", &n);
    arr[cnt] = n;
    if (n != 1)
    {
        do
        {
            if (n % 2 == 0)
            {
                n /= 2;
            }
            else
            {
                n = n * 3 + 1;
            }
            cnt++;
            arr[cnt] = n;
        } while (n != 1);
    }
    for (int i = cnt; i >= 0; i--)
    {
        printf("%d ", arr[i]);
    }
    system("pause");
    return 0;
}