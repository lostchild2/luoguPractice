#include <stdio.h>
#include <math.h>
int main(void)
{
    int s0, i0, re, n, s, i, r = 0, temp; // s是易感者人数,i是感染者人数
    double b, y;
    scanf("%d%d%d", &s0, &i0, &n);
    scanf("%lf%lf", &b, &y);
    for (int a = 0; a < n; a++)
    {
        r += ceil(y * i0); //恢复者
        re = ceil(y * i0);
        if (ceil(b * i0 * s0) >= s0)
        {
            i0 += s0;
            s0 = 0;
        }
        else
        {
            temp = ceil(b * s0 * i0); //变成感染者
            s0 -= temp;
            i0 += temp; //易感染者变感染者
        }
        i0 -= re; //感染者恢复
    }
    printf("%d %d %d", s0, i0, r);
    system("pause");
    return 0;
}