#include <stdio.h>
int main(void)
{
    int n, w, h, num;
    scanf("%d%d%d", &n, &w, &h);
    int len = w * w + h * h;
    for (int i = 0; i < n; i++)
    {
        scanf("%d", &num);
        if (num * num <= len)
        {
            printf("DA\n");
        }
        else
        {
            printf("NE\n");
        }
    }
    system("pause");
    return 0;
}