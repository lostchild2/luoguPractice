#include <stdio.h>
int main(void)
{
    long long n, p, k;
    scanf("%d%d%d", &n, &p, &k);
    printf("%lld", p * k % n);
    system("pause");
    return 0;
}