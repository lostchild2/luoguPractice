#include <stdio.h>
int main(void)
{
    long long a, b;
    scanf("%lld%lld", &a, &b);
    printf("%lld", a - b);
    system("pause");
    return 0;
}