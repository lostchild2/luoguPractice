#include <stdio.h>
int main(void)
{
    double hp = 10, jy = 0, dhp, djy;
    int i = 0, level = 0, n;
    scanf("%d", &n);
    for (i = 0; i < n; i++)
    {
        scanf("%lf%lf", &dhp, &djy);
        hp -= dhp;
        if (hp > 0)
        {
            if (hp > 10)
            {
                hp = 10;
            }
            jy += djy;
        }
        else
        {
            break;
        }
    }
    i = 1;
    int j = (int)jy;
    while (j >= 1)
    {
        if ((j -= i) >= 0)
        {
            level++;
        }
        else
        {
            j += i;
            break;
        }
        i *= 2;
    }
    printf("%d %d", level, j);
    system("pause");
    return 0;
}