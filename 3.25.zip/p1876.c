#include <stdio.h>
long int arr[100000000] = {0};
int main(void)
{
    int i = 0, n, j;
    scanf("%d", &n);
    for (i = 1; i <= n; i++)
    {
        for (j = 1; j <= n; j++)
        {
            if (i * j > n)
            {
                break;
            }
            arr[i * j - 1] += 1;
        }
    }
    for (i = 0; i < n; i++)
    {
        if (arr[i] % 2)
        {
            printf("%d ", i + 1);
        }
    }
    system("pause");
    return 0;
}