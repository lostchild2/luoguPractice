#include <stdio.h>
#include <math.h>
int getSum(int s)
{
    int sum = 1, i, j;
    for (i = 2; i < s; i++)
    {
        if (s % i == 0)
        {
            sum += i;
        }
    }
    return sum;
}
int main(void)
{
    int arr[100], s, i, j, sum = 1, temp, temp2;
    scanf("%d", &s);
    int ret;
    for (j = s;; j++)
    {
        for (i = 2; i < j; i++)
        {
            if (j % i == 0)
            {
                sum += i;
            }
        }
        if (sum > 206)
        {
            ret = getSum(sum);
        }
        if (j == ret && j != sum)
        {
            printf("%d %d", ret, sum);
            break;
        }
        sum = 1;
        ret = 0;
    }
    system("pause");
    return 0;
}