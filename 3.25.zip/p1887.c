#include <stdio.h>
int main(void)
{
    int N, M, i, a;
    int arr[100];
    scanf("%d%d", &N, &M);
    for (i = 0; i < M; i++)
    {
        arr[i] = N / M;
    }
    for (i = 0; i < N % M; i++)
    {
        arr[M - i - 1] += 1;
    }
    for (i = 0; i < M; i++)
    {
        printf("%d ", arr[i]);
    }
    system("pause");
    return 0;
}