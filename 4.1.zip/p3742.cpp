#include <cstdio>
#include <iostream>
using namespace std;
int n;
char x[103], y[103], ans[103];
int main()
{
  scanf("%d", &n);
  scanf("%s", x);
  scanf("%s", y);
  for (int i = 0; i < n; i++)
  {
    if (x[i] > y[i])
      ans[i] = y[i];
    else if (x[i] == y[i])
      ans[i] = x[i] + 1;
    else if (x[i] < y[i])
    {
      printf("-1");
      return 0;
    }
  }
  printf("%s", ans);
  return 0;
}