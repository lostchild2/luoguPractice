#include <stdio.h>
int main(void)
{
    int n;
    scanf("%d", &n);
    char ch;
    int i = 0;
    char arr[101];
    scanf("%s", arr);
    int cnt = 0;
    int flag = 0;
    for (i = 0; i < n - 1; i++)
    {
        if (arr[i] == 'V' && arr[i + 1] == 'K')
        {
            cnt++;
            continue;
        }
        if (arr[i] == 'V' && (arr[i + 1] != 'V' || arr[i + 2] != 'K') && flag == 0)
        {
            cnt++;
            flag = 1;
        }
        if (arr[i] == 'K' && arr[i + 1] == 'K' && flag == 0 && (i == 0 || arr[i - 1] != 'V'))
        {
            flag = 1;
            cnt++;
        }
    }
    printf("%d", cnt);
    system("pause");
    return 0;
}