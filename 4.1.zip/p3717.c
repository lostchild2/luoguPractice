#include <stdio.h>
#include <math.h>
double distance(int a, int b, int x, int y)
{
    return sqrt((a - x) * (a - x) + (b - y) * (b - y));
}
int main(void)
{
    int n, m, r;
    int arr[101][101] = {0};
    int i = 0;
    int x;
    int y;
    int a, b;
    scanf("%d%d%d", &n, &m, &r);
    for (i = 0; i < m; i++)
    {
        scanf("%d%d", &x, &y);
        for (a = 1; a <= n; a++)
        {
            for (b = 1; b <= n; b++)
            {
                if (distance(a, b, x, y) <= r)
                {
                    arr[a][b] = 1;
                }
            }
        }
    }
    int cnt = 0;
    int j = 0;

    for (i = 1; i <= n; i++)
    {
        for (j = 1; j <= n; j++)
        {
            if (arr[i][j] == 1)
            {
                cnt++;
            }
        }
    }
    printf("%d", cnt);
    system("pause");
    return 0;
}