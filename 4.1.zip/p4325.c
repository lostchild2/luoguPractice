#include <stdio.h>
int main(void)
{
    int i = 0;
    int arr[10];
    int num = 0;
    for (i = 0; i < 10; i++)
    {
        scanf("%d", &num);
        arr[i] = num % 42;
    }
    int j = 0;
    int temp = 0;
    for (i = 0; i < 9; i++)
    {
        for (j = 0; j < 9 - i; j++)
        {
            if (arr[j] > arr[j + 1])
            {
                temp = arr[j];
                arr[j] = arr[j + 1];
                arr[j + 1] = temp;
            }
        }
    }
    int cnt = 0;
    for (i = 0; i < 9; i++)
    {
        if (arr[i] == arr[i + 1])
        {
            cnt++;
        }
    }
    printf("%d", 10 - cnt);
    system("pause");
    return 0;
}