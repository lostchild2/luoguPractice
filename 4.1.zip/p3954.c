#include <stdio.h>
int main(void)
{
    int a, b, c;
    scanf("%d%d%d", &a, &b, &c);
    printf("%d", a * 2 / 10 + b * 3 / 10 + c * 5 / 10);
    system("pause");
    return 0;
}