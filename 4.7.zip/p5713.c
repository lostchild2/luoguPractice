#include <stdio.h>
int main(void)
{
    int n;
    scanf("%d", &n);
    int local = n * 5;
    int luogu = n * 3 + 11;
    if (local < luogu)
    {
        printf("local");
    }
    else
    {
        printf("luogu");
    }
    system("pause");
    return 0;
}