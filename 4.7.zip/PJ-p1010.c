#include <stdio.h>
void ans(int n)
{
    int i = 1, cnt = 0;
    printf("2");
    while (i <= n)
    {
        i *= 2;
        cnt++;
    }
    i /= 2;

    cnt--; //回到前一项
    if (cnt == 2 || cnt == 0)
    {
        printf("(%d)", cnt);
    }
    if (cnt > 2)
    {
        printf("(");
        ans(cnt);
        printf(")");
    }
    n = (n - i);
    if (n)
    {
        printf("+");
        ans(n);
    } //剩余的项相加,如果是0就不用+
}
int main(void)
{
    int n;
    scanf("%d", &n);
    ans(n);
    system("pause");
    return 0;
}