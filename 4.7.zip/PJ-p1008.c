#include <stdio.h>
int main(void)
{
    int sum = 1;
    for (int i = 1; i <= 9; i++)
    {
        sum *= i;
    }
    for (int a = 123; a < 329; a++)
    {
        int b = a * 2;
        int c = a * 3;
        if ((a % 10) * (a / 10 % 10) * (a / 100) * (b % 10) * (b / 10 % 10) * (b / 100) * (c % 10) * (c / 10 % 10) * (c / 100) == sum)
        {
            printf("%d %d %d\n", a, b, c);
        }
    }
    system("pause");
    return 0;
}