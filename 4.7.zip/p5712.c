#include <stdio.h>
int main(void)
{
    int n;
    scanf("%d", &n);
    if (n <= 1)
    {
        printf("Today, I ate %d apple.", n);
    }
    else
    {
        printf("Today, I ate %d apples.", n);
    }
    system("pause");
    return 0;
}