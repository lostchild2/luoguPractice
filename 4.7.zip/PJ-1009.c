#include <stdio.h>
#include <string.h>
int main(void)
{
    int a[101] = {0}, b[101] = {0};
    a[0] = 1;
    b[0] = 1;
    int n = 0;
    scanf("%d", &n);
    for (int i = 2; i <= n; i++)
    {
        for (int j = 0; j <= 100; j++)
        {
            a[j] *= i;
        } //必须先乘每一位数
        for (int j = 0; j <= 100; j++)
        {
            if (a[j] >= 10)
            {
                a[j + 1] += a[j] / 10;
                a[j] %= 10;
            }
        } //算出阶乘，并用a数组存储
        for (int j = 0; j <= 100; j++)
        {
            b[j] += a[j];
            if (b[j] >= 10)
            {
                b[j + 1] += b[j] / 10;
                b[j] %= 10;
            }
        } //全部加起来，存储在b数组
    }
    int flag = 0;
    for (int i = 100; i >= 0; i--)
    {
        if (flag == 1)
        {
            printf("%d", b[i]);
        }
        if ((b[i] == 0 && b[i - 1] != 0) || flag == 1)
        {
            flag = 1;
        }
    }
    system("pause");
    return 0;
}