#include <stdio.h>
#include <math.h>
double dist(int x, int y, int n, int x1, int y1)
{
    return sqrt((double)((x - x1) * (x - x1) + (y - y1) * (y - y1)));
}
int main(void)
{
    int n, x, y, i, r, cnt = 0, arrr[100], arrx[100], arry[100], x1, x2, y1, y2;
    scanf("%d", &n);
    for (i = 0; i < n; i++)
    {
        scanf("%d", &x);
        arrx[i] = x;
    }
    for (i = 0; i < n; i++)
    {
        scanf("%d", &y);
        arry[i] = y;
    }
    for (i = 0; i < n; i++)
    {
        scanf("%d", &r);
        arrr[i] = r;
    }
    scanf("%d%d%d%d", &x1, &y1, &x2, &y2);
    for (i = 0; i < n; i++)
    {
        if (((dist(arrx[i], arry[i], n, x1, y1) < arrr[i]) && (dist(arrx[i], arry[i], n, x2, y2) > arrr[i])) || ((dist(arrx[i], arry[i], n, x1, y1) > arrr[i]) && (dist(arrx[i], arry[i], n, x2, y2) < arrr[i])))
        {
            cnt++;
        }
    }
    printf("%d", cnt);
    system("pause");
    return 0;
}