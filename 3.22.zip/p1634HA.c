#include <stdio.h>
int main(void)
{
    int x, n, i;
    long long sum = 1;
    scanf("%d%d", &x, &n);
    for (i = 0; i < n; i++)
    {
        sum += (sum * x);
    }
    printf("%d", sum);
    system("pause");
    return 0;
}