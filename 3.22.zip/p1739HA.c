#include <stdio.h>
int main(void)
{
    char ch;
    int cnt1 = 0, cnt2 = 0, flag = 0;
    while ((ch = getchar()) != '@')
    {
        if (ch == '(')
        {
            cnt1++;
            flag = 1;
        }
        else if (ch == ')')
        {
            if (flag == 0)
            {
                break;
            }
            cnt2++;
        }
    }
    if (flag == 0 || cnt1 != cnt2)
    {
        printf("NO");
    }
    else
    {
        printf("YES");
    }
    system("pause");
    return 0;
}