#include <stdio.h>
#include <math.h>
int main(void)
{
    int a = 1, b = 1, c = 2, n, i;
    scanf("%d", &n);
    for (i = 0; i <= n - 3; i++)
    {
        c = a + b;
        a = b;
        b = c;
    }
    if (n == 1 || n == 2)
    {
        printf("1.00");
    }
    else if (n == 3)
    {
        printf("2.00");
    }
    else
    {
        printf("%d.00", c);
    }
    system("pause");
    return 0;
}