#include <stdio.h>
int main(void)
{
    int hour, min, second, hour2, min2, second2, n, time, time2;
    scanf("%d:%d:%d", &hour, &min, &second);
    scanf("%d:%d:%d", &hour2, &min2, &second2);
    scanf("%d", &n);
    time = hour * 3600 + min * 60 + second;
    time2 = hour2 * 3600 + min2 * 60 + second2;
    printf("%d", (time2 - time) * n);
    system("pause");
    return 0;
}