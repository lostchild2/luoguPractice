#include <stdio.h>
int sum(int num)
{
    int s = 0;
    do
    {
        s += num % 10;
    } while (num /= 10);
    return s;
}
int main(void)
{
    int l, d, x, min = 100000, max = 0;
    scanf("%d%d%d", &l, &d, &x);
    for (int i = l; i <= d; i++)
    {
        if (sum(i) == x)
        {
            if (i > max)
            {
                max = i;
            }
            if (i < min)
            {
                min = i;
            }
        }
    }
    printf("%d\n%d", min, max);
    system("pause");
    return 0;
}