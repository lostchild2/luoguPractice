#include <cstdio>
#include <string>
#include <iostream>
using namespace std;
string s;
int k, len;
int a[100001];
int main()
{
	scanf("%d", &k);
	cin >> s;
	for (int i = s.length() - 1; i >= 0; --i)
		a[++len] = s[i] - '0'; //转换成数字
	a[k + 1]++;				   //处理k
	len = max(len, k + 1);	   //获取位数
	for (int i = 1; i <= len; ++i)
		if (a[i] > 9)
			a[i + 1]++, a[i] %= 10; //处理进位
	if (a[len + 1])
		++len; //最高位的处理
	for (int i = len; i >= 1; --i)
		printf("%d", a[i]); //倒序输出结果
	return 0;
}