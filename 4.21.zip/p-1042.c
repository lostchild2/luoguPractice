#include <stdio.h>
#include <math.h>
int main(void)
{
    char ch;
    int win = 0, lose = 0;
    int a = 1, arr[62503] = {0};
    while ((ch = getchar()) != 'E')
    {
        if (ch == 'W')
        {
            arr[a] = 1;
            a++;
        }
        else if (ch == 'L')
        {
            arr[a] = 2;
            a++;
        }
    }
    int cnt1 = 0, cnt2 = 0;
    // for (int i = 1; arr[i] != 0; i++)
    // {

    //     if (arr[i] == 1)
    //     {
    //         cnt1++;
    //     }
    //     if (arr[i] == 2)
    //     {
    //         cnt2++;
    //     }
    //     // printf("%d ", arr[i]);
    // }
    // printf("%d %d", cnt1, cnt2);
    for (int i = 1;; i++)
    {
        if (arr[i] == 1)
        {
            win++;
        }
        else if (arr[i] == 2)
        {
            lose++;
        }
        if ((win >= 11 || lose >= 11) && abs(win - lose) >= 2)
        {
            printf("%d:%d\n", win, lose);
            win = 0;
            lose = 0;
        }
        if (i >= a)
        {
            printf("%d:%d\n", win, lose);
            break;
        }
    }
    printf("\n");
    win = 0, lose = 0;
    for (int i = 1;; i++)
    {
        if (arr[i] == 1)
        {
            win++;
        }
        else if (arr[i] == 2)
        {
            lose++;
        }
        if ((win >= 21 || lose >= 21) && abs(win - lose) >= 2)
        {
            printf("%d:%d\n", win, lose);
            win = 0;
            lose = 0;
        }
        if (i >= a)
        {
            printf("%d:%d\n", win, lose);
            break;
        }
    }
    system("pause");
    return 0;
}