#include <stdio.h>
#include <stdlib.h>
void merge(int a[], int start, int mid, int end)
{
    int *tmp = (int *)malloc((end - start + 1) * sizeof(int));
    int i = start;
    int j = mid + 1;
    int k = 0;
    while (i <= mid && j <= end)
    {
        if (a[i] <= a[j])
        {
            tmp[k] = a[i];
            k++;
            i++;
        }
        else
        {
            tmp[k] = a[j];
            k++;
            j++;
        }
    }
    while (i <= mid)
    {
        tmp[k] = a[i];
        k++;
        i++;
    }
    while (j <= end)
    {
        tmp[k] = a[j];
        k++;
        j++;
    }
    for (int i = 0; i < k; i++)
    {
        a[start + i] = tmp[i];
    }
    free(tmp);
}
void merge_sort(int a[], int start, int end)
{
    if (a == NULL || start >= end)
    {
        return;
    }
    int mid = (start + end) / 2;
    merge_sort(a, start, mid);
    merge_sort(a, mid + 1, end);
    merge(a, start, mid, end);
}
int main(void)
{
    int a[6] = {5, 3, 6, 2, 7, 9};
    merge_sort(a, 0, 5);
    for (int i = 0; i < 6; i++)
    {
        printf("%d ", a[i]);
    }
    system("pause");
    return 0;
}