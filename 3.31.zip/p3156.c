#include <stdio.h>
int main(void)
{
    int n, m, i;
    // char ch;
    int num;
    char arr[2000001];
    scanf("%d%d", &n, &m);
    for (i = 0; i < n; i++)
    {
        scanf("%d", &num);
        arr[i] = num;
    }
    int cnt = 0;
    for (i = 0; i < m; i++)
    {
        scanf("%d", &cnt);
        printf("%d\n", arr[cnt - 1]);
    }
    system("pause");
    return 0;
}