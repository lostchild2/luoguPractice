#include <stdio.h>
int main(void)
{
    int n, num;
    scanf("%d", &n);
    int i = 0;
    for (i = 0; i < n; i++)
    {
        scanf("%d", &num);
        if (num % 2 == 1)
        {
            printf("zs wins");
        }
        else
        {
            printf("pb wins");
        }
        printf("\n");
    }
    system("pause");
    return 0;
}