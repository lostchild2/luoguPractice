#include <stdio.h>
int main(void)
{
    int arr[1001][1001], n, i, j, num, cnt = 0, a, b, flag = 0;
    int count[10001], cCnt = 0;
    scanf("%d", &n);
    for (i = 0; i < n; i++)
    {
        for (j = 0; j < n; j++)
        {
            scanf("%d", &num);
            arr[i][j] = num;
        }
    }
    for (i = 0; i < n; i++)
    {
        for (j = 0; j < n; j++)
        {
            if (arr[i][j] == 0)
            {
                flag = 1;
                for (a = 0; a < n; a++)
                {
                    if (arr[a][j] == 1)
                    {
                        cnt++;
                    }
                }
                for (b = 0; b < n; b++)
                {
                    if (arr[i][b] == 1)
                    {
                        cnt++;
                    }
                }
                count[cCnt] = cnt;
                cCnt++;
                cnt = 0;
            }
        }
    }
    int max = 0;
    for (i = 0; i < cCnt; i++)
    {
        if (count[i] > max)
        {
            max = count[i];
        }
    }
    if (flag == 0)
    {
        printf("Bad Game!");
    }
    printf("%d", max);
    system("pause");
    return 0;
}