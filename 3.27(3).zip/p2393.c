#include <stdio.h>
int main(void)
{
    char ch;
    double num;
    int a, b;
    while (1)
    {
        b = scanf("%d", &a);
        printf("%d %d", a, b);
    }
    system("pause");
    return 0;
}
