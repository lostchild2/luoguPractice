#include <stdio.h>
int main(void)
{
    int n, num, i, j, fCnt = 0, zCnt = 0;
    unsigned int sum = 0;
    int arr[1001];
    scanf("%d", &n);
    for (i = 0; i < n; i++)
    {
        scanf("%d", &num);
        if (num == 5)
        {
            fCnt++;
        }
        else
        {
            zCnt++;
        }
        arr[i] = num;
    }
    if (fCnt >= 9 && zCnt > 0)
    {
        for (i = 0; i < fCnt / 9 * 9; i++)
        {
            printf("5");
        }
        for (i = 1; i < zCnt; i++)
        {
            printf("0");
        }
        printf("%d", sum);
    }
    else if (fCnt < 9 && zCnt > 0)
    {
        printf("0");
    }
    else if (zCnt == 0)
    {
        printf("-1");
    }
    system("pause");
    return 0;
}