#include <stdio.h>
int main(void)
{
    int n, b, arr[20001];
    scanf("%d%d", &n, &b);
    int i = 0, num;
    for (i = 0; i < n; i++)
    {
        scanf("%d", &num);
        arr[i] = num;
    }
    int j = 0, temp;
    for (i = 0; i < n - 1; i++)
    {
        for (j = 0; j < n - 1 - i; j++)
        {
            if (arr[j] < arr[j + 1])
            {
                temp = arr[j];
                arr[j] = arr[j + 1];
                arr[j + 1] = temp;
            }
        }
    }
    int sum = 0;
    for (i = 0; i < n; i++)
    {
        if (sum >= b)
        {
            break;
        }
        sum += arr[i];
    }
    printf("%d", i);
    system("pause");
    return 0;
}