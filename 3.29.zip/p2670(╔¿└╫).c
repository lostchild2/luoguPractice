#include <stdio.h>
char arr[103][103] = {'0'};
int main(void)
{
    int n, m, arr2[101][101]; //
    int i, j, flag = 0, cnt = 0;
    char ch;
    scanf("%d%d", &n, &m);
    for (i = 1; i <= n; i++)
    {
        scanf("%*c", &ch);
        for (j = 1; j <= m; j++)
        {
            scanf("%c", &ch);
            arr[i][j] = ch;
        }
        // printf("\n");
    } //初始数据存储

    for (i = 1; i <= n; i++)
    {
        for (j = 1; j <= m; j++)
        {
            if (arr[i][j] == '*')
            {
                printf("*");
                continue;
            }
            if (arr[i - 1][j - 1] == '*')
            {
                cnt++;
            }
            if (arr[i - 1][j] == '*')
            {
                cnt++;
            }
            if (arr[i - 1][j + 1] == '*')
            {
                cnt++;
            }
            if (arr[i][j - 1] == '*')
            {
                cnt++;
            }
            if (arr[i][j + 1] == '*')
            {
                cnt++;
            }
            if (arr[i + 1][j - 1] == '*')
            {
                cnt++;
            }
            if (arr[i + 1][j] == '*')
            {
                cnt++;
            }
            if (arr[i + 1][j + 1] == '*')
            {
                cnt++;
            }
            printf("%d", cnt);
            cnt = 0;
        }
        printf("\n");
    }

    system("pause");
    return 0;
}