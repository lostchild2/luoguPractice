#include <iostream>
#include <cmath>
int main(void)
{
	using namespace std;
	int r, b, c, d, e, score;
	cin >> r >> b >> c >> d >> e;
	if (c + d >= 2 * e)
	{
		score = r * c + b * d;
	}
	else
	{
		if (r >= b)
		{
			score = b * e * 2 + (r - b) * c;
		}
		else if (r < b)
		{
			score = r * e * 2 + (b - r) * d;
		}
	}
	cout << score;
	return 0;
}