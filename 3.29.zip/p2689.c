#include <stdio.h>
#include <math.h>
int main(void)
{
    int x1, y1, x2, y2;
    scanf("%d%d", &x1, &y1);
    scanf("%d%d", &x2, &y2);
    int x = x2 - x1;
    int y = y2 - y1;
    int t;
    char arr[51];
    scanf("%d", &t);
    int i = 0;
    char ch;
    scanf("%*c");
    int Ecnt = 0, Wcnt = 0, Ncnt = 0, Scnt = 0;
    for (i = 0; i < t; i++)
    {
        scanf("%c%*c", &ch);
        if (ch == 'E')
        {
            Ecnt++;
            continue;
        }
        if (ch == 'W')
        {
            Wcnt++;
            continue;
        }
        if (ch == 'N')
        {
            Ncnt++;
            continue;
        }
        if (ch == 'S')
        {
            Scnt++;
            continue;
        }
    }
    if (x >= 0)
    {
        if (Ecnt >= x)
        {
            if (y >= 0)
            {
                if (Ncnt >= y)
                {
                    printf("%d", x + y);
                }
                else
                {
                    printf("-1");
                }
            }
            else if (y < 0)
            {
                y = (-y);
                if (Scnt >= y)
                {
                    printf("%d", x + y);
                }
                else
                {
                    printf("-1");
                }
            }
        }
        else
        {
            printf("-1");
        }
    }
    else if (x < 0)
    {
        x = (-x);
        if (Ecnt > x)
        {
            if (y >= 0)
            {
                if (Ncnt >= y)
                {
                    printf("%d", x + y);
                }
                else
                {
                    printf("-1");
                }
            }
            else if (y < 0)
            {
                y = (-y);
                if (Scnt >= y)
                {
                    printf("%d", x + y);
                }
                else
                {
                    printf("-1");
                }
            }
        }
    }
    // if (x > 0)
    // {
    //     x = x - Ecnt;
    //     if (x < 0)
    //     {
    //         x = 0;
    //     }
    // }
    // else
    // {
    //     x = (-x);
    //     x = x - Wcnt;
    //     if (x < 0)
    //     {
    //         x = 0;
    //     }
    // }
    // if (y > 0)
    // {
    //     y = y - Ncnt;
    //     if (y < 0)
    //     {
    //         y = 0;
    //     }
    // }
    // else
    // {
    //     y = (-y);
    //     y = y - Scnt;
    //     if (y < 0)
    //     {
    //         y = 0;
    //     }
    // }
    // if (x + y <= t)
    // {
    //     printf("%d", x + y);
    // }
    // else
    // {
    //     printf("-1");
    // }
    system("pause");
    return 0;
}