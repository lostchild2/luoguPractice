#include <stdio.h>
#include <string.h>
int main(void)
{
    char arr[100001];
    int cnt = 0;
    int i = 0, flag = 1;
    scanf("%s", arr);
    int len = strlen(arr);
    for (i = 0; i < len; i++)
    {
        if (arr[i] != arr[i + 1] && i != len - 1)
        {
            cnt++;
        }
    }
    if (arr[len - 1] == '0')
    {
        cnt++;
    }
    printf("%d", cnt);
    system("pause");
    return 0;
}