#include <iostream>
#include <string.h>
using namespace std;
int main()
{
    char arr[20], num;
    cin >> arr;
    string dq = "";
    for (int i = 0; i < 3; i++)
    {
        dq += arr[i];
    }
    if (dq != "MDA")
    {
        printf("1 1 1 1 1");
    }
    else
    {
        for (int i = strlen(arr) - 1; i >= 3; i--)
        {
            if (arr[i] >= '0' && arr[i] <= '9')
            {
                num = arr[i];
                break;
            }
        }
        if (num == '1' || num == '9')
        {
            printf("1 0 0 0 0");
        }
        else if (num == '2' || num == '8')
        {
            printf("0 1 0 0 0");
        }
        else if (num == '3' || num == '7')
        {
            printf("0 0 1 0 0");
        }
        else if (num == '4' || num == '6')
        {
            printf("0 0 0 1 0");
        }
        else if (num == '5' || num == '0')
        {
            printf("0 0 0 0 1");
        }
    }
    return 0;
}