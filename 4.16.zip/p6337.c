#include <stdio.h>
int ans(int num)
{
    if (num == 1)
    {
        return 2;
    }
    else
    {
        return ans(num - 1) + (num / 2 + 1);
    }
}
int main(void)
{
    int num;
    scanf("%d", &num);
    printf("%d", ans(num));
    system("pause");
    return 0;
}