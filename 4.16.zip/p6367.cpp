#include <iostream>
using namespace std;
int main()
{
    string name[22];
    string str;
    int cnt[22] = {0}, ans = 0, sum = 0;
    int n;
    cin >> n; //一共拿几次
    for (int i = 0; i < n; i++)
    {
        cin >> str; //孩子的名字
        for (int j = 0; j < 22; j++)
        {
            if (str == name[j])
            { //如果孩子再次出现
                for (int a = 0; a < 22; a++)
                {
                    if (cnt[a] == 0)
                    {
                        break;
                    }
                    if (a != j)
                    {
                        sum += cnt[a];
                    }
                }
                if (cnt[j] > sum)
                {
                    ans++;
                }
                sum = 0;
                cnt[j]++;
                break;
            }
            //孩子没出现过
            else if (name[j] == "")
            {
                name[j] = str;
                cnt[j]++;
                break;
            }
        }
    }
    cout << ans;
    return 0;
}