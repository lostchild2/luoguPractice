#include <stdio.h>
#include <math.h>
int main(void)
{
    int arr[4], cha;
    for (int i = 0; i < 3; i++)
    {
        scanf("%d", &arr[i]);
    }
    for (int i = 0; i < 2; i++)
    {
        for (int j = i + 1; j < 3; j++)
        {
            if (arr[i] > arr[j])
            {
                int temp = arr[i];
                arr[i] = arr[j];
                arr[j] = temp;
            }
        }
    }
    if ((arr[1] - arr[0]) <= (arr[2] - arr[1]))
    {
        cha = arr[1] - arr[0];
    }
    else
    {
        cha = arr[2] - arr[1];
    }
    int i = 0;
    while ((arr[i] + cha) == arr[i + 1])
    {
        i++;
    }
    printf("%d", arr[i] + cha);
    system("pause");
    return 0;
}