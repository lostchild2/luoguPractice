#include <iostream>
#include <string.h>
using namespace std;
char a[21][21];
string s = "{", x = "", x2 = "";
int k;
int main()
{
    int r, c;
    cin >> r >> c;
    for (int i = 1; i <= r; i++)
    {
        for (int j = 1; j <= c; j++)
        {
            cin >> a[i][j];
        }
    } //输入数据
    for (int i = 0; i <= r; i++)
    {
        a[i][0] = '#';
    }
    for (int j = 0; j <= c; j++)
    {
        a[0][j] = '#';
    }
    for (int i = 1; i <= r; i++)
    {
        x = "";
        for (int j = 1; j <= c; j++)
        {
            if (a[i][j] == '#')
            {
                if (x < s && x.size() >= 2)
                {
                    s = x;
                }
                x = "";
                continue;
            }
            else
            {
                x += a[i][j];
            }
        }
        if (x < s && x.size() >= 2)
        {
            s = x;
        }
    }
    for (int j = 1; j <= c; j++)
    {
        x = "";
        for (int i = 0; i <= r; i++)
        {
            if (a[i][j] == '#')
            {
                if (x < s && x.size() >= 2)
                {
                    s = x;
                }
                x = "";
                continue;
            }
            else
            {
                x += a[i][j];
            }
        }
        if (x < s && x.size() >= 2)
        {
            s = x;
        }
    }
    cout << s;
    return 0;
}