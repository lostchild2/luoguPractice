#include <stdio.h>
int gcd(int x, int y)
{
    int temp;
    while (y != 0)
    {
        temp = x % y;
        x = y;
        y = temp;
    }
    return x;
}
int main(void)
{
    int cnt = 2, i = 0, x = 1, y = 1, a, b, temp;
    for (i = 0; i < cnt; i++)
    {
        scanf("%d/%d", &a, &b);
        x *= a;
        y *= b;
    }
    temp = gcd(x, y);
    printf("%d %d", x / temp, y / temp);
    system("pause");
    return 0;
}