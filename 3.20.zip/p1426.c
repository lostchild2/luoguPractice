#include <stdio.h>
int main(void)
{
    int s, x;
    double speed = 7, distance = 0, time;
    scanf("%d%d", &s, &x);
    while ((distance += speed) <= s)
    {
        speed *= 0.98;
    }
    time = (s - distance) / speed;
    distance = (1.0 - time) * speed + ((1.0 + time) * speed * 0.98);
    if (distance >= 2 * x)
    {
        printf("n");
    }
    else
    {
        printf("y");
    }
    system("pause");
    return 0;
}