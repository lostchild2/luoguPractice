#include <stdio.h>
int main(void)
{
    int cnt, i, j, num, outCnt = 0;
    int arr[100];
    scanf("%d", &cnt);
    for (i = 0; i < cnt; i++)
    {
        scanf("%d", &num);
        arr[i] = num;
    }
    for (i = 0; i < cnt; i++)
    {
        for (j = 0; j < i; j++)
        {
            if (arr[i] > arr[j])
            {
                outCnt++;
            }
        }
        printf("%d ", outCnt);
        outCnt = 0;
    }
    system("pause");
    return 0;
}