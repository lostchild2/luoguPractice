#include <stdio.h>
int main(void)
{
    int cnt = -1, i;
    int num;
    int arr[100];
    do
    {
        scanf("%d", &num);
        cnt++;
        arr[cnt] = num;
    } while (num != 0);

    for (i = cnt - 1; i >= 0; i--)
    {
        printf("%d ", arr[i]);
    }
    system("pause");
    return 0;
}