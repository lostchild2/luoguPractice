#include <stdio.h>
int arr[100][100] = {0};
int final[100][100] = {0};
int main(void)
{
    int n, m, x, y, x1, y1, x2, y2, i, j, a, b, c, d;
    scanf("%d%d%d%d", &n, &m, &x, &y);
    for (a = 1; a <= x; a++)
    {
        scanf("%d%d%d%d", &x1, &y1, &x2, &y2);
        for (i = x1; i <= x2; i++)
        {
            for (j = x1; j <= x2; j++)
            {
                arr[i][j] += 1;
                final[i][j] = a;
            }
        }
    }

    for (i = 0; i < y; i++)
    {
        scanf("%d%d", &c, &d);
        if (arr[c][d] == 0)
        {
            printf("N\n");
        }
        else
        {
            printf("Y %d %d\n", arr[c][d], final[c][d]);
        }
    }
    system("pause");
    return 0;
}