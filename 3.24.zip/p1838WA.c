#include <stdio.h>
#include <math.h>
int main(void)
{
    int i = 0, num, a = -1, b = -1, j = 0, flag = 0;
    int arr1[10], arr2[10];
    char ch[9];
    scanf("%s", ch);
    do
    {
        if (i % 2 == 0)
        {
            a++;
            arr1[a] = ch[i] - '0';
        }
        else
        {
            b++;
            arr2[b] = ch[i] - '0';
        }
        i++;
    } while (ch[i] != '\0');
    // if (i == 9)
    // {
    //     printf("drew");
    // }

    // printf("%d", abs(arr1[j] - arr1[j + 1]));
    for (j = 0; j <= a - 2; j++)
    {
        if (abs(arr1[j] - arr1[j + 1]) == abs(arr1[j + 1] - arr1[j + 2]))
        {
            printf("xiaoa wins");
            flag = 1;
            break;
        }
    }
    if (flag == 0)
    {
        for (j = 0; j <= b - 2; j++)
        {
            if (abs(arr2[j] - arr2[j + 1]) == abs(arr2[j + 1] - arr2[j + 2]))
            {
                printf("uim wins");
                flag = 1;
                break;
            }
        }
    }
    if (flag == 0)
    {
        printf("drew");
    }
    system("pause");
    return 0;
}