#include <stdio.h>
int a, b, c, d;
int ans(int num)
{
    int ret = 0, temp1 = num, temp2 = num;
    while (temp1 > (a + b))
    {
        temp1 -= (a + b);
    }
    if (temp1 <= a)
    {
        ret++;
    }
    while (temp2 > (c + d))
    {
        temp2 -= (c + d);
    }
    if (temp2 <= c)
    {
        ret++;
    }
    return ret;
}
int main(void)
{
    scanf("%d%d%d%d", &a, &b, &c, &d);
    int arr[3];
    scanf("%d%d%d", &arr[0], &arr[1], &arr[2]);
    for (int i = 0; i < 3; i++)
    {
        int ret = ans(arr[i]);
        if (ret == 2)
        {
            printf("both\n");
        }
        else if (ret == 1)
        {
            printf("one\n");
        }
        else if (ret == 0)
        {
            printf("none\n");
        }
    }
    system("pause");
    return 0;
}