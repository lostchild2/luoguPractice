#include <stdio.h>
#include <string.h>
int main(void)
{
    char ch;
    while ((ch = getchar()) != '\n')
    {
        printf("%c", ch);
        if (ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u')
        {
            getchar();
            getchar();
        }
    }
    system("pause");
    return 0;
}