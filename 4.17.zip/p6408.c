#include <stdio.h>
int main(void)
{
    int ansi = 0, ans = 0, num, sum = 0;
    for (int i = 0; i < 5; i++)
    {
        for (int j = 0; j < 4; j++)
        {
            scanf("%d", &num);
            sum += num;
        }
        if (sum > ans)
        {
            ans = sum;
            ansi = i;
        }
        sum = 0;
    }
    printf("%d %d", ansi + 1, ans);
    system("pause");
    return 0;
}