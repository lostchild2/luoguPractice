#include <stdio.h>
int main(void)
{
    long long n, arr[105], ans[105], a, b, sum = 0;
    scanf("%d", &n);
    for (int i = 1; i <= n; i++)
    {
        scanf("%lld", &a);
        ans[i] = a * i - sum;
        sum += ans[i];
    }
    for (int i = 1; i <= n; i++)
    {
        printf("%lld ", ans[i]);
    }
    system("pause");
    return 0;
}