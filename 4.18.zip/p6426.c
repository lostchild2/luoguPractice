#include <stdio.h>
int main(void)
{
    int a, b, c;
    scanf("%d%d%d", &a, &b, &c);
    int ans;
    int ans1 = b - a;
    int ans2 = c - b;
    if (ans1 > ans2)
    {
        ans = ans1;
    }
    else
    {
        ans = ans2;
    }
    printf("%d", ans - 1);
    system("pause");
    return 0;
}