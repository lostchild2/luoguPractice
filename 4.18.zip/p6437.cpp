#include <iostream>
using namespace std;
int Total, Max;
int Array[101];
int main()
{
	register int i, j, k;
	cin >> Total >> Max;
	for (i = 1; i <= Total; i++)
	{
		cin >> Array[i];
	}
	register int Ans = 0;
	for (i = 1; i <= Total; i++)
	{
		for (j = i + 1; j <= Total; j++)
		{
			for (k = j + 1; k <= Total; k++)
			{
				if (Array[i] + Array[j] + Array[k] <= Max)
				{
					Ans = max(Ans, Array[i] + Array[j] + Array[k]);
				}
			}
		}
	}
	cout << Ans << endl;
	return 0;
}