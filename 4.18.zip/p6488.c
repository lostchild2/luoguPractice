#include <stdio.h>
int main(void)
{
    long long l, p, arr[10];
    scanf("%lld%lld", &l, &p);
    for (int i = 1; i <= 5; i++)
    {
        scanf("%lld", &arr[i]);
        printf("%lld ", -l * p + arr[i]);
    }

    system("pause");
    return 0;
}