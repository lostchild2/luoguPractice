#include <stdio.h>
int main(void)
{
    int n, ans = 1;
    scanf("%d", &n);
    for (int i = 1; i < n; i++)
    {
        ans += 1;
        ans *= 2;
    }
    printf("%d", ans);
    system("pause");
    return 0;
}