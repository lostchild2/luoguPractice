#include <stdio.h>
int judge(int year)
{
    if (year % 4 != 0)
    {
        return 0;
    }
    else
    {
        if (year % 100 != 0)
        {
            return 1;
        }
        else
        {
            if (year % 400 != 0)
            {
                return 0;
            }
            else
            {
                return 1;
            }
        }
    }
}
int main(void)
{
    int x, y, cnt = 0;
    int arr[3000];
    scanf("%d%d", &x, &y);
    for (int i = x; i <= y; i++)
    {
        if (judge(i) == 1)
        {
            cnt++;
            arr[cnt] = i;
        }
    }
    printf("%d\n", cnt);
    for (int i = 1; i <= cnt; i++)
    {
        printf("%d ", arr[i]);
    }
    system("pause");
    return 0;
}