#include <stdio.h>
int ans(int num)
{
    if (num == 1)
    {
        return 1;
    }
    else
    {
        return num * ans(num - 1);
    }
}
int main(void)
{
    int n;
    scanf("%d", &n);
    printf("%d", ans(n));
    system("pause");
    return 0;
}