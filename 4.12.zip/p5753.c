#include <stdio.h>
int main(void)
{
    int v, v0;
    scanf("%d", &v);
    scanf("%d", &v0);
    int n = (v / 2 / v0);
    if (v < v0)
    {
        printf("0");
    }
    else
    {
        if (v * n - v0 * n * n > v * (n + 1) - v0 * (n + 1) * (n + 1))
        {
            printf("%d", n);
        }
        else if (v * n - v0 * n * n < v * (n + 1) - v0 * (n + 1) * (n + 1))
        {
            printf("%d", n + 1);
        }
        else
        {
            printf("0");
        }
    }
    system("pause");
    return 0;
}