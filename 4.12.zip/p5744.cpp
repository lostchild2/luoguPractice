#include <stdio.h>
struct stu
{
    char name[101];
    int year;
    int grade;
};
int main(void)
{
    struct stu stu[6];
    int n;
    scanf("%d", &n);
    for (int i = 0; i < n; i++)
    {
        scanf("%s%d")
    }
    system("pause");
    return 0;
}