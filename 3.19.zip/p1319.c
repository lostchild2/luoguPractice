#include <stdio.h>
int main(void)
{
    int N, cnt, i, j, num = 0;
    scanf("%d", &N);
    for (i = 0; i < N * N;)
    {
        scanf("%d", &cnt);
        for (j = 0; j < cnt; j++)
        {
            printf("%d", num);
            i++;
            if (i % N == 0)
            {
                printf("\n");
            }
        }
        num = !num;
    }
    system("pause");
    return 0;
}