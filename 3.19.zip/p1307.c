#include <stdio.h>
int main(void)
{
    int trans, num, flag;
    scanf("%d", &num);
    if (num < 0)
    {
        flag = 0;
    }
    else
    {
        flag = 1;
    }
    do
    {
        trans = trans * 10 + num % 10;
    } while (num /= 10);
    printf("%d", trans);

    system("pause");
    return 0;
}