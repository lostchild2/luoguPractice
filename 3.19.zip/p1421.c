#include <stdio.h>
int main(void)
{
    int price = 19;
    int y, j;
    int money;
    scanf("%d%d", &y, &j);
    money = y * 10 + j;
    printf("%d", money / price);
    system("pause");
    return 0;
}