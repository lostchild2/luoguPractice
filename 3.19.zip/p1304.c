#include <stdio.h>
#include <math.h>
int judgeZS(int num);
int main(void)
{
    int i, j, N;
    scanf("%d", &N);
    for (i = 4; i <= N; i += 2)
    {
        for (j = 2; j <= N / 2; j++)
        {
            if (judgeZS(j) && judgeZS(i - j))
            {
                printf("%d=%d+%d\n", i, j, i - j);
                break;
            }
        }
    }
    system("pause");
    return 0;
}
int judgeZS(int num)
{
    int i;
    for (i = 2; i <= sqrt(num); i++)
    {
        if (num % i == 0)
        {
            break;
        }
    }
    if (i > sqrt(num))
    {
        return 1;
    }
    else
    {
        return 0;
    }
}