#include <stdio.h>
int main(void)
{
    int cnt, arr[20], num, i, sum = 0, j;
    scanf("%d", &cnt);
    for (i = 0; i < cnt; i++)
    {
        scanf("%d", &num);
        arr[i] = num;
    }
    for (i = 1; i < cnt - 1; i++)
    {
        for (j = 1; j <= i; j++)
        {
            if (arr[i] < arr[i - j] && arr[i] < arr[i + j])
            {
                sum++;
                break;
            }
            else if (arr[i] > arr[i - j] || arr[i] > arr[i + j])
            {
                break;
            }
        }
    }
    printf("%d", sum);
    system("pause");
    return 0;
}