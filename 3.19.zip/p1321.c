#include <stdio.h>
#include <stdlib.h>
int main(void)
{
    char ch[100];
    scanf("%s", ch);
    // printf("%d %d", sizeof(ch) / sizeof(ch[0]), strlen(ch));
    int i = 0, boy = 0, girl = 0;
    for (i = 0; i < strlen(ch); i++)
    {
        if (ch[i] == 'b' || ch[i + 1] == 'o' || ch[i + 2] == 'y')
        {
            boy++;
        }
        if (ch[i] == 'g' || ch[i + 1] == 'i' || ch[i + 2] == 'r' || ch[i + 3] == 'l')
        {
            girl++;
        }
    }
    printf("%d\n%d", boy, girl);
    system("pause");
    return 0;
}