#include <stdio.h>
int main(void)
{
    int W;
    double money;
    scanf("%d", &W);
    if (W <= 150)
    {
        money = W * 0.4463;
    }
    else if (W > 150 && W <= 400)
    {
        money = 150 * 0.4463 + (W - 150) * 0.4663;
    }
    else
    {
        money = 150 * 0.4463 + 250 * 0.4663 + (W - 400) * 0.5663;
    }
    printf("%.1lf", money);
    system("pause");
    return 0;
}