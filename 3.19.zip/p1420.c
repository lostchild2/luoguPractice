#include <stdio.h>
int main(void)
{
    int n, num, i, cnt = 1, j = -1;
    scanf("%d", &n);
    int arr[10000];
    int tar[2000];
    for (i = 0; i < n; i++)
    {
        scanf("%d", &num);
        arr[i] = num;
    }
    for (i = 0; i < n; i++)
    {
        if (arr[i] + 1 == arr[i + 1])
        {
            cnt++;
        }
        else
        {
            j++;
            tar[j] = cnt;
            cnt = 1;
        }
    }
    for (i = 0; i < j; i++)
    {
        cnt = tar[i];
        if (tar[i] < tar[i + 1])
        {
            cnt = tar[i + 1];
        }
    }
    printf("%d", cnt);
    system("pause");
    return 0;
}