#include <stdio.h>
int main(void)
{
    int n = 0;
    scanf("%d", &n);
    n /= 364;
    int x, k;
    for (k = 1;; k++)
    {
        for (x = 100; x >= 1; x--)
        {
            if ((x + 3 * k) == n)
            {
                break;
            }
        }
        if ((x + 3 * k) == n)
        {
            break;
        }
    }
    printf("%d\n%d", x, k);
    system("pause");
    return 0;
}