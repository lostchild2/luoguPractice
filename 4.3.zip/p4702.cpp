#include <iostream>
int main()
{
	using namespace std;
	int n;
	cin >> n;
	long long sum = 0, num = 0;
	for (int i = 0; i < n; i++)
	{
		cin >> num;
		sum += num;
	}
	if (sum % 2 == 1)
	{
		cout << "Alice";
	}
	else
	{
		cout << "Bob";
	}
	return 0;
}