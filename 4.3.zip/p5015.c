#include <stdio.h>
#include <string.h>
int main(void)
{
    char arr[6];
    int i = 0;
    char ch;
    while ((ch = getchar()) != '\n')
    {
        arr[i] = ch;
        // printf("arr[i]=%c ", arr[i]);
        i++;
    }
    int cnt = 0;
    int len = strlen(arr);
    for (i = 0; i < len; i++)
    {
        if (arr[i] >= 'A' && arr[i] <= 'Z')
            cnt++;
        if (arr[i] >= 'a' && arr[i] <= 'z')
            cnt++;
        if (arr[i] >= '0' && arr[i] <= '9')
            cnt++;
    }
    printf("%d", cnt);
    system("pause");
    return 0;
}