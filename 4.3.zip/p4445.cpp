#include<iostream>
int main()
{
	using namespace std;
	int n, i;
	int arr[100001];
	cin >> n;
	int num = 0;
	long long sum = 0;
	for (i = 0; i < n; i++) {
		cin >> num;
		arr[i] = num;
		if (i > 0 && arr[i - 1] > arr[i]) {
			sum += arr[i - 1];
		}
		else if(i>0) {
			sum += arr[i];
		}
		//cout << sum<<endl;
	}
	cout << sum;
	return 0;
}