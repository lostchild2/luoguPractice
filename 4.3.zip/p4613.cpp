#include <iostream>
int main()
{
	using namespace std;
	long long num;
	int arrGz[101];
	int arrHz[101];
	int n;
	cin >> n;
	for (int i = 0; i < n; i++)
	{
		cin >> num;
		arrGz[i] = num;
	}
	for (int i = 0; i < n; i++)
	{
		cin >> num;
		arrHz[i] = num;
	}
	for (int i = 0; i < n - 1; i++)
	{
		for (int j = 0; j < n - 1 - i; j++)
		{
			int temp = 0;
			if (arrGz[j] > arrGz[j + 1])
			{
				temp = arrGz[j];
				arrGz[j] = arrGz[j + 1];
				arrGz[j + 1] = temp;
			}
			if (arrHz[j] > arrHz[j + 1])
			{
				temp = arrHz[j];
				arrHz[j] = arrHz[j + 1];
				arrHz[j + 1] = temp;
			}
		}
	}
	int i = 0;
	for (i = 0; i < n; i++)
	{
		if (arrGz[i] > arrHz[i])
		{
			cout << "NE";
			break;
		}
	}
	if (i == n)
	{
		cout << "DA";
	}
	return 0;
}