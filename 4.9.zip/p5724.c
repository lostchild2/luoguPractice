#include <stdio.h>
int main(void)
{
    int n, num;
    int arr[101];
    int min = 1001;
    int max = 0;
    scanf("%d", &n);
    for (int i = 0; i < n; i++)
    {
        scanf("%d", &arr[i]);
        if (arr[i] < min)
        {
            min = arr[i];
        }
        if (arr[i] > max)
        {
            max = arr[i];
        }
    }
    printf("%d", max - min);
    system("pause");
    return 0;
}