#include <stdio.h>
int main(void)
{
    int n, num;
    char arr[21][12];
    scanf("%d", &n);
    int i = 0;
    for (int i = 0; i < n; i++)
    {
        scanf("%s", arr[i][0]);
    }
    for (int i = n - 1; i >= 0; i--)
    {
        printf("%d", arr[i][0]);
    }
    system("pause");
    return 0;
}