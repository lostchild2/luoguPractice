#include <stdio.h>
int trans(int num)
{
    int ret = 0;
    ret = num % 10;
    while ((num /= 10) != 0)
    {
        ret = ret * 10 + num % 10;
    }
    return ret;
}
int main(void)
{
    int n, arr[101], m, i = 0, ret, sum, ans = 0;
    scanf("%d", &n);
    scanf("%d", &m);
    // scanf("%d", &m);
    // printf("%d", trans(m));
    do
    {
        do
        {
            arr[i] = m % 10;
            ret = trans(m);
            arr[i] += (ret % 10);
            i++;
        } while ((m /= 10) != 0);
        for (int i = 0; i < 101; i++)
        {
            if (arr[i] >= n)
            {
                arr[i] -= n;
                arr[i + 1] += 1;
            }
            sum = sum * n + arr[i];
        }
        printf("%d\n", sum);
        ans++;
    } while (sum != trans(sum));
    printf("%d", ans);
    system("pause");
    return 0;
}
