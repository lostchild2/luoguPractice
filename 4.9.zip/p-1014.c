#include <stdio.h>
int main(void)
{
    int cnt;
    scanf("%d", &cnt);
    int n = 1;
    while (n * (n + 1) / 2 < cnt)
    {
        n++;
    }
    int fm = n * (n + 1) / 2;
    int cz = fm - cnt;
    if (n % 2 == 0)
    {

        printf("%d/%d", n - cz, 1 + cz);
    }
    else
    {
        printf("%d/%d", 1 + cz, n - cz);
    }
    system("pause");
    return 0;
}