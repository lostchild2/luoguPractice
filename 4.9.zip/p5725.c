#include <stdio.h>
int main(void)
{
    int n, cnt = 1;
    scanf("%d", &n);
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < n; j++)
        {
            if (cnt / 10 == 0)
            {
                printf("0%d", cnt);
            }
            else
            {
                printf("%d", cnt);
            }
            cnt++;
        }
        printf("\n");
    }
    cnt = 1;
    printf("\n");
    for (int i = 1; i <= n; i++)
    {
        for (int a = 1; a <= n - i; a++)
        {
            printf("  ");
        }
        for (int b = 1; b <= i; b++)
        {
            if (cnt / 10 == 0)
            {
                printf("0%d", cnt);
            }
            else
            {
                printf("%d", cnt);
            }
            cnt++;
        }
        printf("\n");
    }
    system("pause");
    return 0;
}