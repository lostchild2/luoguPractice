#include <stdio.h>
#include <string.h>
int main(void)
{
    char ch[10];
    scanf("%s", ch);
    int len = strlen(ch);
    for (int i = len - 1; i >= 0; i--)
    {
        printf("%c", ch[i]);
    }
    system("pause");
    return 0;
}