#include <stdio.h>
int main(void)
{
    int num;
    scanf("%d", &num);
    int arr[4];
    if (num % 2 == 0)
    {
        arr[1] = 1;
        arr[3] = 0;
        if (num > 4 && num <= 12)
        {
            arr[0] = 1;
            arr[2] = 0;
        }
        else
        {
            arr[0] = 0;
            arr[2] = 1;
        }
    }
    else
    {
        arr[0] = 0;
        if (num > 4 && num <= 12)
        {
            arr[1] = 1;
            arr[2] = 1;
            arr[3] = 0;
        }
        else
        {
            arr[3] = 1;
            arr[2] = 0;
            arr[1] = 0;
        }
    }
    for (int i = 0; i < 4; i++)
    {
        printf("%d ", arr[i]);
    }
    system("pause");
    return 0;
}