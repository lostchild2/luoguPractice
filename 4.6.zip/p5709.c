#include <stdio.h>
int main(void)
{
    int m, t, s;
    scanf("%d%d%d", &m, &t, &s);
    int ans = 0;
    if (t == 0)
    {
        printf("0");
    }
    else
    {
        if (s % t > 0)
        {
            ans++;
        }
        ans += (s / t);
        if (ans > m)
        {
            printf("0");
        }
        else
        {
            printf("%d", m - ans);
        }
    }
    system("puase");
    return 0;
}