#include <stdio.h>
int main(void)
{
    double t;
    int n;
    scanf("%lf%d", &t, &n);
    printf("%.3lf\n%d", t / n, n * 2);
    system("pause");
    return 0;
}