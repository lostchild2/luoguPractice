#include <stdio.h>
int main(void)
{
    char ch;
    scanf("%c", &ch);
    printf("%c", ch - 'a' + 'A');
    return 0;
}