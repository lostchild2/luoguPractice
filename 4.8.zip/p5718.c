#include <stdio.h>
int main(void)
{
    int arr[101], n;
    scanf("%d", &n);
    int min = 1000;
    for (int i = 0; i < n; i++)
    {
        scanf("%d", &arr[i]);
        if (arr[i] < min)
        {
            min = arr[i];
        }
    }
    printf("%d", min);
    system("pause");
    return 0;
}