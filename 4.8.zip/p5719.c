#include <stdio.h>
int main(void)
{
    int n, k;
    int num1 = 0, num2 = 0, cnt1 = 0, cnt2 = 0;
    scanf("%d%d", &n, &k);
    for (int i = 1; i <= n; i++)
    {
        if (i % k == 0)
        {
            num1 += i;
            cnt1++;
        }
        else
        {
            num2 += i;
            cnt2++;
        }
    }
    printf("%.1lf %.1lf", num1 * (1.0) / cnt1, num2 * (1.0) / cnt2);
    system("pause");
    return 0;
}