#include <stdio.h>
int main(void)
{
    int flag = 0;
    int year, month;
    scanf("%d%d", &year, &month);
    if (year % 4 == 0)
    {
        if (year % 100 != 0)
        {
            flag = 1;
        }
        else
        {
            if (year % 400 == 0)
            {
                flag = 1;
            }
            else
            {
                flag = 0;
            }
        }
    }
    else
    {
        flag = 0;
    }
    int arr[12] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
    if (flag == 1)
    {
        arr[1]++;
        printf("%d", arr[month - 1]);
    }
    else
    {
        printf("%d", arr[month - 1]);
    }
    system("pause");
    return 0;
}
