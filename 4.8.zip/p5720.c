#include <stdio.h>
int main(void)
{
    int len, day = 1;
    scanf("%d", &len);
    while (len != 1)
    {
        len /= 2;
        day++;
    }
    printf("%d", day);
    system("pause");
    return 0;
}