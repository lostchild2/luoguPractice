#include <stdio.h>
int main(void)
{
    int i = 0, n, cnt = 1;
    scanf("%d", &n);
    for (int i = 0; i < n; i++)
    {
        for (int j = i; j < n; j++)
        {
            if (cnt / 10 == 0)
            {
                printf("0%d", cnt);
                cnt++;
            }
            else
            {
                printf("%d", cnt);
                cnt++;
            }
        }
        printf("\n");
    }
    system("pause");
    return 0;
}