#include <stdio.h>
#include <string.h>
int main(void)
{
    char arr[16];
    scanf("%s", arr);
    int len = strlen(arr);
    int i, j;
    for (j = 1; j <= len + 1; j++)
    {
        if (j == len + 1)
        {
            printf(".");
            break;
        }
        if (j % 3 == 0)
        {
            printf("..*.");
        }
        else
        {
            printf("..#.");
        }
    } //第一排
    printf("\n");
    for (i = 1; i <= len + 1; i++)
    {
        if (i == len + 1)
        {
            printf(".");
            break;
        }
        if (i % 3 == 0)
        {
            printf(".*.*");
        }
        else
        {
            printf(".#.#");
        }
    } //第二排
    printf("\n");
    for (i = 1; i <= len + 1; i++)
    {
        if (i == len + 1 && i % 3 != 1)
        {
            printf("#");
            break;
        }
        else if (i == len + 1 && i % 3 == 1)
        {
            printf("*");
            break;
        }
        if ((i % 3 == 0 || i % 3 == 1) && i != 1)
        {
            printf("*.%c.", arr[i - 1]);
        }
        else
        {
            printf("#.%c.", arr[i - 1]);
        }
    } //第三排
    printf("\n");
    for (i = 1; i <= len + 1; i++)
    {
        if (i == len + 1)
        {
            printf(".");
            break;
        }
        if (i % 3 == 0)
        {
            printf(".*.*");
        }
        else
        {
            printf(".#.#");
        }
    } //第二排
    printf("\n");
    for (j = 1; j <= len + 1; j++)
    {
        if (j == len + 1)
        {
            printf(".");
            break;
        }
        if (j % 3 == 0)
        {
            printf("..*.");
        }
        else
        {
            printf("..#.");
        }
    } //第一排
    system("pause");
    return 0;
}