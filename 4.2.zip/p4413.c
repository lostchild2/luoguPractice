#include <stdio.h>
int main(void)
{
    int s, r1, r2;
    scanf("%d%d", &r1, &s);
    printf("%d", 2 * s - r1);
    system("pause");
    return 0;
}