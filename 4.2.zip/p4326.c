#include <stdio.h>
#define PI 3.141592653589783238462643383279
int main(void)
{
    double r;
    scanf("%lf", &r);
    printf("%.6lf\n", PI * r * r);
    printf("%.6lf", 2 * r * r);
    system("pause");
    return 0;
}