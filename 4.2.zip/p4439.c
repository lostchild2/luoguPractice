#include <stdio.h>
#include <string.h>
int main(void)
{
    int n;
    char arr[1000000];
    char ch;
    scanf("%d", &n);
    int i = 0;
    int cnt = 0;
    // scanf("%*c");
    for (i = 0; i < n; i++)
    {
        getchar();
        scanf("%c", &arr[i]);
        // printf("arr[i]=%c\n", arr[i]);
        if (i > 0 && arr[i] == arr[i - 1])
        {
            cnt++;
        }
    }
    printf("%d", n - cnt + 1);
    system("pause");
    return 0;
}