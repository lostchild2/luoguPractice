#include <stdio.h>
int main(void)
{
    int arr[3];
    char ch[4];
    int i = 0;
    int num;
    for (i = 0; i < 3; i++)
    {
        scanf("%d", &num);
        arr[i] = num;
    }
    scanf("%s", ch);
    int temp;
    int j = 0;
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 2 - i; j++)
        {
            if (arr[j] > arr[j + 1])
            {
                temp = arr[j];
                arr[j] = arr[j + 1];
                arr[j + 1] = temp;
            }
        }
    }
    for (i = 0; i < 3; i++)
    {
        printf("%d ", arr[ch[i] - 'A']);
    }
    system("pause");
    return 0;
}