#include <stdio.h>
int ans[1001] = {0};
int main(void)
{
    int n, m, k;
    scanf("%d%d%d", &n, &m, &k);
    int i = 0, j = 0;

    int arr[1001][1001];
    int num = 0;
    for (i = 0; i < n; i++)
    {
        for (j = 0; j < m; j++)
        {
            scanf("%d", &num);
            arr[i][j] = num;
            // printf("%d ", arr[i][j]);
        }
    }
    int a = 0;
    for (i = 0; i < m; i++)
    {
        for (a = 1; a <= k; a++)
        {
            for (j = 0; j < n; j++)
            {
                // printf("arr[i][j]=%d,a=%d ", arr[i][j], a);
                if (arr[j][i] == a)
                {
                    ans[a - 1]++;
                    // printf("true ");
                    break;
                }
            }
        }
    }
    for (i = 0; i < k; i++)
    {
        printf("%d ", ans[i]);
    }
    system("pause");
    return 0;
}