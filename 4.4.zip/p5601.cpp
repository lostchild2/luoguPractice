#include <iostream>
#include <string.h>
#include <stdlib.h>
using namespace std;
struct pre
{
	string title;
	string ans;
} p[101];
struct pro
{
	string title;
	string ans[4];
	int num;
} s[101];
int main()
{
	int n, p;
	struct pre pre[101];
	struct pro pro[101];
	int arr[101];
	char ans[4] = {'A', 'B', 'C', 'D'};
	cin >> n >> p; //出n道题，做p道题
	for (int i = 0; i < n; i++)
	{
		cin >> pre[i].title >> pre[i].ans;
	} //初始化题库
	for (int i = 0; i < p; i++)
	{
		cin >> pro[i].title >> pro[i].ans[0] >> pro[i].ans[1] >> pro[i].ans[2] >> pro[i].ans[3];
	} //初始化题目
	for (int i = 0; i < n; i++)
	{
		for (int j = 0; j < p; j++)
		{
			if (pre[i].title == pro[j].title)
			{
				pro[j].num = i;
			}
		}
	} //给题目找到对应的题库
	for (int i = 0; i < p; i++)
	{
		for (int j = 0; j < 4; j++)
		{
			if (pre[pro[i].num].ans == pro[i].ans[j] && i != (p - 1))
			{
				printf("%c\n", ans[j]);
			}
			else if (pre[pro[i].num].ans == pro[i].ans[j] && i == (p - 1))
			{
				printf("%c", ans[j]);
			}
		}
	}
	return 0;
}