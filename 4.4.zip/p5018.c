#include <stdio.h>
int main(void)
{
    int n;
    int sum = 0;
    int get = 0;
    int k = 0;
    int i = 0;
    int num = 0;
    scanf("%d", &n);
    for (i = 0; i < n; i++)
    {
        scanf("%d", &num);
        sum += num;
    }
    for (i = 0; i < n; i++)
    {
        scanf("%d", &num);
        get += num;
    }
    k = sum - get;
    printf("%.6lf", (double)(sum * 3 - get * 2) / k);
    system("pause");
    return 0;
}