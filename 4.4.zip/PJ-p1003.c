#include <stdio.h>
// long long arr[100001][100001] = {0};
int main(void)
{
    int n;
    scanf("%d", &n);
    int a, b, g, k, x, y;
    int i = 0, j = 0, c = 0;
    int a1[10001], b1[10001], g1[10001], k1[10001];
    for (i = 0; i < n; i++)
    {
        scanf("%d%d%d%d", &a, &b, &g, &k);
        a1[i] = a;
        b1[i] = b;
        g1[i] = g;
        k1[i] = k;
    }
    scanf("%d%d", &x, &y);
    for (i = n - 1; i >= 0; i--)
    {
        if (x >= a1[i] && x <= a1[i] + g1[i] && y >= b1[i] && y <= b1[i] + k1[i])
        {
            printf("%d", i + 1);
            break;
        }
    }
    if (i < 0)
    {
        printf("-1");
    }
    // for (i = 0; i < n; i++)
    // {
    //     scanf("%d%d%d%d", &a, &b, &g, &k);
    //     for (j = a; j <= g; j++)
    //     {
    //         for (c = b; c <= k; c++)
    //         {
    //             arr[j][c]++;
    //         }
    //     }
    // }
    // scanf("%d%d", &x, &y);
    // if (arr[x][y] == 0)
    // {
    //     printf("-1");
    // }
    // else
    // {
    //     printf("%d", arr[x][y]);
    // }
    system("pause");
    return 0;
}