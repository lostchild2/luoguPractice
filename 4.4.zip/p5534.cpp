#include <iostream>
int main()
{
	using namespace std;
	long long a1, a2, d, n;
	cin >> a1 >> a2 >> n;
	d = a2 - a1;
	long long sum = a1 + a2;
	for (int i = 0; i < n - 2; i++)
	{
		a2 += d;
		sum += a2;
	}
	cout << sum;
	return 0;
}